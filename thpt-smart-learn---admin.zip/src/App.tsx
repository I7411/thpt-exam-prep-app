/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { AdminTab, Screen, User, Document, Exam } from './types';
import { BottomNav } from './components/BottomNav';
import { Header, Card } from './components/Shared';
import { LoginScreen, SettingsScreen } from './components/AuthSettings';
import { DashboardScreen } from './components/Dashboard';
import { UserListScreen } from './components/UserManagement';
import { UserDetailScreen } from './components/UserDetail';
import { ContentListScreen } from './components/ContentManagement';

// --- Mock Data ---

const MOCK_USERS: User[] = [
  { id: '1', name: 'Huỳnh Thanh Minh Tâm', email: 'tam.huynh@school.edu.vn', phone: '0901234567', role: 'STUDENT', status: 'ACTIVE', class: '12A1', avgScore: 8.5, completion: 68, createdAt: '2023-10-01' },
  { id: '2', name: 'Nguyễn Văn Hải', email: 'hai.nguyen@school.edu.vn', phone: '0907654321', role: 'TEACHER', status: 'ACTIVE', subject: 'Toán', docsCount: 15, examCount: 5, createdAt: '2023-09-15' },
  { id: '3', name: 'Lê Thị Hồng', email: 'hong.le@school.edu.vn', phone: '0988776655', role: 'STUDENT', status: 'PENDING', class: '12A2', createdAt: '2023-11-10' },
  { id: '4', name: 'Trần Minh Tuấn', email: 'tuan.tran@school.edu.vn', phone: '0900112233', role: 'ADMIN', status: 'ACTIVE', createdAt: '2023-01-01' },
];

const MOCK_DOCS: Document[] = [
  { id: '1', title: 'Chuyên đề Hàm số 12', subject: 'Toán', type: 'PDF', author: 'Nguyễn Văn Hải', status: 'PUBLISHED', views: 1200, downloads: 450, updatedAt: '2023-10-20' },
  { id: '2', title: 'Ôn tập Nghị luận xã hội', subject: 'Văn', type: 'DOC', author: 'Trần Thị Thuý', status: 'PUBLISHED', views: 850, downloads: 200, updatedAt: '2023-10-18' },
  { id: '3', title: 'Video ngữ pháp Câu điều kiện', subject: 'Anh', type: 'VIDEO', author: 'John Doe', status: 'DRAFT', views: 0, downloads: 0, updatedAt: '2023-11-01' },
];

const MOCK_EXAMS: Exam[] = [
  { id: '1', title: 'Đề thi thử Toán số 01', subject: 'Toán', questionsCount: 50, duration: 90, difficulty: 'HARD', attempts: 1250, status: 'PUBLISHED' },
  { id: '2', title: 'Đề minh hoạ Bộ GD 2024', subject: 'Văn', questionsCount: 1, duration: 120, difficulty: 'MEDIUM', attempts: 3500, status: 'PUBLISHED' },
  { id: '3', title: 'Kiểm tra 15p Tiếng Anh', subject: 'Anh', questionsCount: 20, duration: 15, difficulty: 'EASY', attempts: 800, status: 'LOCKED' },
];

const PIE_DATA = [
  { name: 'Hoạt động', value: 400, color: '#00236f' },
  { name: 'Không hoạt động', value: 100, color: '#e1e3e4' },
];

// --- Simple Form Screens Inline ---

const UserFormScreen = ({ onBack, isEdit }: { onBack: () => void, isEdit?: boolean }) => (
  <div className="pb-24">
    <Header title={isEdit ? "Sửa tài khoản" : "Thêm tài khoản mới"} showBack onBack={onBack} />
    <main className="p-4 space-y-6">
       <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-primary uppercase tracking-widest ml-1">Họ và tên</label>
            <input type="text" placeholder="Nhập họ tên đầy đủ" className="w-full bg-white border-2 border-surface focus:border-primary/20 rounded-xl p-4 font-bold outline-none" />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-primary uppercase tracking-widest ml-1">Email</label>
            <input type="email" placeholder="example@school.com" className="w-full bg-white border-2 border-surface focus:border-primary/20 rounded-xl p-4 font-bold outline-none" />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-primary uppercase tracking-widest ml-1">Vai trò</label>
            <select className="w-full bg-white border-2 border-surface focus:border-primary/20 rounded-xl p-4 font-bold outline-none appearance-none">
              <option>Học sinh</option>
              <option>Giáo viên</option>
              <option>Admin</option>
            </select>
          </div>
       </div>
       <button onClick={onBack} className="w-full bg-primary text-white py-4 rounded-2xl font-bold text-lg shadow-card">
         Lưu tài khoản
       </button>
    </main>
  </div>
);

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<AdminTab>(AdminTab.DASHBOARD);
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const renderScreen = () => {
    switch (activeTab) {
      case AdminTab.DASHBOARD:
        if (screen === 'dashboard') return <DashboardScreen setScreen={setScreen} />;
        if (screen === 'user_list') return <UserListScreen users={MOCK_USERS} onBack={() => setScreen('dashboard')} onDetail={(u) => { setCurrentUser(u); setScreen('user_detail'); }} onAdd={() => setScreen('user_form')} />;
        if (screen === 'user_detail') return currentUser ? <UserDetailScreen user={currentUser} onBack={() => setScreen('user_list')} onEdit={() => setScreen('user_form')} /> : null;
        if (screen === 'user_form') return <UserFormScreen onBack={() => setScreen('user_list')} isEdit={!!currentUser} />;
        if (screen === 'doc_list' || screen === 'exam_list') return <ContentListScreen docs={MOCK_DOCS} exams={MOCK_EXAMS} onBack={() => setScreen('dashboard')} />;
        return <DashboardScreen setScreen={setScreen} />;

      case AdminTab.USERS:
        if (screen === 'user_detail') return currentUser ? <UserDetailScreen user={currentUser} onBack={() => setActiveTab(AdminTab.USERS)} onEdit={() => setScreen('user_form')} /> : null;
        if (screen === 'user_form') return <UserFormScreen onBack={() => setActiveTab(AdminTab.USERS)} isEdit={!!currentUser} />;
        return <UserListScreen users={MOCK_USERS} onBack={() => setActiveTab(AdminTab.DASHBOARD)} onDetail={(u) => { setCurrentUser(u); setScreen('user_detail'); }} onAdd={() => setScreen('user_form')} />;

      case AdminTab.CONTENT:
        return <ContentListScreen docs={MOCK_DOCS} exams={MOCK_EXAMS} onBack={() => setActiveTab(AdminTab.DASHBOARD)} />;
      
      case AdminTab.REPORTS:
        return (
          <div className="pb-24">
            <Header title="Báo cáo thống kê" />
            <main className="p-4 space-y-6">
              <Card className="h-64">
                <h3 className="text-xs font-bold text-primary mb-4 uppercase tracking-[0.2em]">Hoạt động học sinh</h3>
                <ResponsiveContainer width="100%" height="80%">
                  <PieChart>
                    <Pie data={PIE_DATA} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5}>
                      {PIE_DATA.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex justify-center gap-6 mt-2">
                   <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-primary"></div>
                      <span className="text-[10px] font-bold">Hoạt động (80%)</span>
                   </div>
                   <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-surface-variant"></div>
                      <span className="text-[10px] font-bold">Vắng mặt (20%)</span>
                   </div>
                </div>
              </Card>
              <div className="grid grid-cols-2 gap-4">
                 <Card className="text-center space-y-1">
                    <p className="text-xs font-bold text-on-surface-variant uppercase">Điểm TB Hệ Thống</p>
                    <p className="text-3xl font-black text-primary">7.82</p>
                 </Card>
                 <Card className="text-center space-y-1">
                    <p className="text-xs font-bold text-on-surface-variant uppercase">Tỷ lệ hoàn thành</p>
                    <p className="text-3xl font-black text-secondary">62%</p>
                 </Card>
              </div>
            </main>
          </div>
        );

      case AdminTab.SETTINGS:
        return <SettingsScreen onLogout={() => setIsLoggedIn(false)} />;

      default:
        return <DashboardScreen setScreen={setScreen} />;
    }
  };

  if (!isLoggedIn) {
     return <LoginScreen onLogin={() => setIsLoggedIn(true)} />;
  }

  return (
    <div className="min-h-screen bg-surface">
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab + screen}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {renderScreen()}
        </motion.div>
      </AnimatePresence>
      <BottomNav activeTab={activeTab} setActiveTab={(t) => { setActiveTab(t); setScreen('dashboard'); setCurrentUser(null); }} />
    </div>
  );
}
