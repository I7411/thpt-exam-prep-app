import React, { useState } from 'react';
import { Search, Plus, MoreVertical, UserCircle, Mail } from 'lucide-react';
import { Header, Card, Badge } from './Shared';
import { User, Screen } from '@/src/types';
import { cn } from '@/src/lib/utils';

export const UserListScreen = ({ 
  users, 
  onBack, 
  onDetail, 
  onAdd 
}: { 
  users: User[], 
  onBack: () => void, 
  onDetail: (u: User) => void, 
  onAdd: () => void 
}) => {
  const [filter, setFilter] = useState('ALL');
  const [search, setSearch] = useState('');

  const filters = [
    { id: 'ALL', label: 'Tất cả' },
    { id: 'STUDENT', label: 'Học sinh' },
    { id: 'TEACHER', label: 'Giáo viên' },
    { id: 'LOCKED', label: 'Bị khóa' },
  ];

  const filteredUsers = users.filter(u => {
    const matchesFilter = filter === 'ALL' || u.role === filter || (filter === 'LOCKED' && u.status === 'LOCKED');
    const matchesSearch = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="pb-20">
      <Header title="Quản lý người dùng" showBack onBack={onBack} />
      
      <div className="sticky top-[73px] bg-surface z-20 pb-2">
        <div className="p-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={18} />
            <input 
              type="text" 
              placeholder="Tìm theo tên hoặc email..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white border-2 border-surface focus:border-primary/20 rounded-2xl pl-12 pr-4 py-3.5 font-medium shadow-soft outline-none"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-4 px-4">
            {filters.map((f) => (
              <button 
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={cn(
                  "px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all border",
                  filter === f.id ? "bg-primary text-white border-primary shadow-md" : "bg-white text-on-surface-variant border-surface"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main className="p-4 space-y-4">
        {filteredUsers.map((user) => (
          <Card key={user.id} className="p-3" onClick={() => onDetail(user)}>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold overflow-hidden">
                {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <UserCircle size={24} />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                   <h3 className="text-sm font-bold text-on-surface truncate pr-1">{user.name}</h3>
                   <Badge status={user.status} />
                </div>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mt-1">
                  {user.role} • {user.class || user.subject || 'N/A'}
                </p>
                <div className="flex items-center gap-2 mt-2 opacity-60">
                   <Mail size={10} />
                   <span className="text-[10px] truncate">{user.email}</span>
                </div>
              </div>
              <button className="p-2 hover:bg-surface rounded-full">
                <MoreVertical size={16} className="text-on-surface-variant" />
              </button>
            </div>
          </Card>
        ))}

        {filteredUsers.length === 0 && (
          <div className="text-center py-12">
            <UserCircle size={48} className="mx-auto text-on-surface-variant/20 mb-4" />
            <p className="text-on-surface-variant font-bold">Không tìm thấy người dùng nào</p>
          </div>
        )}
      </main>

      <button 
        onClick={onAdd}
        className="fixed bottom-24 right-6 w-14 h-14 bg-gradient-to-br from-primary to-primary-container text-white rounded-full flex items-center justify-center shadow-card z-30 active:scale-90 transition-all outline-none"
      >
        <Plus size={28} />
      </button>
    </div>
  );
};
