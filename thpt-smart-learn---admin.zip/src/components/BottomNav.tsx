import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  BarChart3, 
  Settings 
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { AdminTab } from '@/src/types';

export const BottomNav = ({ activeTab, setActiveTab }: { activeTab: AdminTab, setActiveTab: (tab: AdminTab) => void }) => {
  const tabs = [
    { id: AdminTab.DASHBOARD, label: 'Tổng quan', icon: LayoutDashboard },
    { id: AdminTab.USERS, label: 'Người dùng', icon: Users },
    { id: AdminTab.CONTENT, label: 'Nội dung', icon: BookOpen },
    { id: AdminTab.REPORTS, label: 'Báo cáo', icon: BarChart3 },
    { id: AdminTab.SETTINGS, label: 'Cài đặt', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 w-full bg-white border-t border-surface flex items-center justify-around px-4 py-2 z-40 md:hidden pb-safe">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex flex-col items-center gap-1 p-2 transition-all rounded-xl",
              isActive ? "text-primary" : "text-on-surface-variant"
            )}
          >
            <div className={cn(
              "p-1.5 rounded-full transition-all",
              isActive && "bg-primary/10 shadow-sm"
            )}>
              <Icon size={22} />
            </div>
            <span className={cn("text-[10px] font-bold tracking-tight", isActive ? "opacity-100" : "opacity-80")}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
