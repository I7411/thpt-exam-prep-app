import React, { useState } from 'react';
import { 
  FileText, 
  ShieldAlert, 
  HelpCircle, 
  MoreVertical, 
  Eye, 
  Download, 
  Plus 
} from 'lucide-react';
import { Header, Card, Badge } from './Shared';
import { Document, Exam } from '@/src/types';
import { cn } from '@/src/lib/utils';

export const ContentListScreen = ({ 
  docs, 
  exams, 
  onBack 
}: { 
  docs: Document[], 
  exams: Exam[], 
  onBack: () => void 
}) => {
  const [tab, setTab] = useState<'DOCS' | 'EXAMS' | 'QUESTIONS'>('DOCS');

  return (
    <div className="pb-24">
      <Header title="Quản lý nội dung" showBack onBack={onBack} />
      
      <div className="p-4">
        <div className="bg-surface-variant/30 p-1 rounded-2xl flex gap-1">
          {[
            { id: 'DOCS', label: 'Tài liệu', icon: FileText },
            { id: 'EXAMS', label: 'Đề thi', icon: ShieldAlert },
            { id: 'QUESTIONS', label: 'Ngân hàng', icon: HelpCircle },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as any)}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold transition-all",
                tab === t.id ? "bg-white text-primary shadow-sm" : "text-on-surface-variant hover:bg-white/50"
              )}
            >
              <t.icon size={16} />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <main className="px-4 space-y-4">
         {tab === 'DOCS' && (
           <>
             {docs.map(doc => (
               <Card key={doc.id} className="p-4">
                 <div className="flex justify-between items-start mb-3">
                   <div className="flex items-center gap-2">
                     <span className="bg-surface text-primary px-2 py-0.5 rounded text-[10px] font-black uppercase">MÔN {doc.subject}</span>
                     <Badge status={doc.status} />
                   </div>
                   <button className="text-on-surface-variant"><MoreVertical size={16} /></button>
                 </div>
                 <h4 className="font-bold text-on-surface mb-2">{doc.title}</h4>
                 <div className="flex items-center justify-between text-[10px] font-bold text-on-surface-variant uppercase tracking-wider opacity-60">
                   <span>Người đăng: {doc.author}</span>
                   <div className="flex items-center gap-3">
                     <span className="flex items-center gap-1"><Eye size={12} /> {doc.views}</span>
                     <span className="flex items-center gap-1"><Download size={12} /> {doc.downloads}</span>
                   </div>
                 </div>
               </Card>
             ))}
           </>
         )}

         {tab === 'EXAMS' && (
           <>
             {exams.map(exam => (
               <Card key={exam.id} className="p-4">
                 <div className="flex justify-between items-start mb-3">
                   <div className="flex items-center gap-2">
                     <span className="bg-surface text-primary px-2 py-0.5 rounded text-[10px] font-black uppercase">MÔN {exam.subject}</span>
                     <Badge status={exam.status} />
                   </div>
                   <button className="text-on-surface-variant"><MoreVertical size={16} /></button>
                 </div>
                 <h4 className="font-bold text-on-surface mb-2">{exam.title}</h4>
                 <div className="grid grid-cols-3 gap-2">
                   <div className="text-center bg-surface p-2 rounded-xl">
                      <p className="text-sm font-black text-primary">{exam.questionsCount}</p>
                      <p className="text-[8px] font-bold text-on-surface-variant uppercase">Câu hỏi</p>
                   </div>
                   <div className="text-center bg-surface p-2 rounded-xl">
                      <p className="text-sm font-black text-primary">{exam.attempts}</p>
                      <p className="text-[8px] font-bold text-on-surface-variant uppercase">Lượt làm</p>
                   </div>
                   <div className="text-center bg-surface p-2 rounded-xl">
                      <p className="text-sm font-black text-secondary tracking-tighter truncate">{exam.difficulty}</p>
                      <p className="text-[8px] font-bold text-on-surface-variant uppercase">Độ khó</p>
                   </div>
                 </div>
               </Card>
             ))}
           </>
         )}

         {tab === 'QUESTIONS' && (
           <div className="text-center py-12">
             <HelpCircle size={48} className="mx-auto text-on-surface-variant/20 mb-4" />
             <p className="text-on-surface-variant font-bold">Quản lý câu hỏi đang được cập nhật</p>
           </div>
         )}
      </main>

      <button 
        className="fixed bottom-24 right-6 w-14 h-14 bg-gradient-to-br from-primary to-primary-container text-white rounded-full flex items-center justify-center shadow-card z-30 active:scale-90 transition-all outline-none"
      >
        <Plus size={28} />
      </button>
    </div>
  );
};
