import React from 'react';
import { Bell, UserCircle, ArrowLeft } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export const Header = ({ title, subtitle, showBack, onBack, showBell = true }: { title: string, subtitle?: string, showBack?: boolean, onBack?: () => void, showBell?: boolean }) => (
  <header className="bg-white border-b border-surface p-4 flex items-center justify-between sticky top-0 z-30">
    <div className="flex items-center gap-3">
      {showBack && (
        <button onClick={onBack} className="p-2 hover:bg-surface rounded-full transition-colors">
          <ArrowLeft size={20} className="text-primary" />
        </button>
      )}
      <div>
        <h1 className="text-lg font-extrabold text-primary tracking-tight leading-none">{title}</h1>
        {subtitle && <p className="text-xs text-on-surface-variant mt-1 font-medium">{subtitle}</p>}
      </div>
    </div>
    <div className="flex items-center gap-3">
      {showBell && (
        <button className="relative p-2 hover:bg-surface rounded-full transition-colors">
          <Bell size={20} className="text-primary" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
      )}
      <div className="w-9 h-9 bg-surface-variant flex items-center justify-center rounded-full overflow-hidden border-2 border-primary/10">
        <UserCircle size={24} className="text-primary" />
      </div>
    </div>
  </header>
);

export const Card = ({ children, className, onClick }: { children: React.ReactNode, className?: string, onClick?: () => void, key?: React.Key }) => (
  <div 
    onClick={onClick}
    className={cn("bg-white rounded-2xl p-4 shadow-soft border border-surface", className, onClick && "active:scale-[0.98] transition-transform cursor-pointer")}
  >
    {children}
  </div>
);

export const Badge = ({ status }: { status: string }) => {
  const styles: Record<string, string> = {
    'ACTIVE': 'bg-green-100 text-green-700',
    'LOCKED': 'bg-red-100 text-red-700',
    'PENDING': 'bg-orange-100 text-orange-700',
    'PUBLISHED': 'bg-blue-100 text-blue-700',
    'DRAFT': 'bg-gray-100 text-gray-700',
    'APPROVED': 'bg-green-100 text-green-700',
    'ERROR': 'bg-red-100 text-red-700',
  };

  const labels: Record<string, string> = {
    'ACTIVE': 'Hoạt động',
    'LOCKED': 'Bị khóa',
    'PENDING': 'Chờ duyệt',
    'PUBLISHED': 'Đã đăng',
    'DRAFT': 'Bản nháp',
    'APPROVED': 'Đã duyệt',
    'ERROR': 'Lỗi',
  };

  return (
    <span className={cn("text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full tracking-wider", styles[status] || 'bg-surface text-on-surface-variant')}>
      {labels[status] || status}
    </span>
  );
};
