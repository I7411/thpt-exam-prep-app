import React from 'react';
import { 
  GraduationCap, 
  Briefcase, 
  FileText, 
  ShieldAlert, 
  ChevronRight, 
  Users,
  HelpCircle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { Header, Card } from './Shared';
import { Screen } from '@/src/types';
import { cn } from '@/src/lib/utils';

const CHẬT_DATA = [
  { name: 'T2', value: 400 },
  { name: 'T3', value: 300 },
  { name: 'T4', value: 600 },
  { name: 'T5', value: 800 },
  { name: 'T6', value: 500 },
  { name: 'T7', value: 900 },
  { name: 'CN', value: 1100 },
];

export const DashboardScreen = ({ setScreen }: { setScreen: (s: Screen) => void }) => {
  const stats = [
    { label: 'Học sinh', value: '4,250', icon: GraduationCap, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Giáo viên', value: '128', icon: Briefcase, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Tài liệu', value: '856', icon: FileText, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Đề thi', value: '245', icon: ShieldAlert, color: 'text-red-600', bg: 'bg-red-50' },
  ];

  const quickActions = [
    { label: 'Quản lý Tài khoản', icon: Users, screen: 'user_list' as Screen },
    { label: 'Quản lý Lớp học', icon: GraduationCap, screen: 'class_list' as Screen },
    { label: 'Quản lý Tài liệu', icon: FileText, screen: 'doc_list' as Screen },
    { label: 'Đề thi & Câu hỏi', icon: HelpCircle, screen: 'exam_list' as Screen },
  ];

  return (
    <div className="pb-20">
      <Header title="Xin chào, Admin" subtitle="Hôm nay hệ thống vẫn hoạt động tốt!" />
      
      <main className="p-4 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat, idx) => (
            <Card key={idx} className="flex flex-col gap-2">
              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", stat.bg)}>
                <stat.icon size={20} className={stat.color} />
              </div>
              <div>
                <p className="text-2xl font-black text-primary leading-tight">{stat.value}</p>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">{stat.label}</p>
              </div>
            </Card>
          ))}
        </div>

        {/* Charts Container */}
        <section className="space-y-4">
          <h2 className="text-sm font-black text-primary uppercase tracking-widest pl-1">Thống kê hoạt động</h2>
          <Card className="p-0 overflow-hidden">
            <div className="p-4 border-b border-surface">
              <h3 className="text-xs font-bold text-on-surface-variant">Lượt làm bài 7 ngày qua</h3>
            </div>
            <div className="h-48 w-full p-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={CHẬT_DATA}>
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#0058be" />
                      <stop offset="100%" stopColor="#00236f" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f1f2" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700, fill: '#757682' }} />
                  <Tooltip 
                    cursor={{ fill: '#f8f9fa' }} 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="value" fill="url(#barGradient)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </section>

        {/* Priority Section */}
        <section className="space-y-4">
          <h2 className="text-sm font-black text-primary uppercase tracking-widest pl-1">Cần xử lý</h2>
          <div className="space-y-3">
             <Card className="flex items-center justify-between p-3 border-l-4 border-orange-500">
               <div className="flex items-center gap-3">
                 <div className="w-10 h-10 bg-orange-50 rounded-full flex items-center justify-center text-orange-600">
                   <Users size={20} />
                 </div>
                 <div>
                   <p className="text-sm font-bold text-on-surface">3 Tài khoản đang chờ duyệt</p>
                   <p className="text-[10px] text-on-surface-variant font-medium">Cập nhật 5 phút trước</p>
                 </div>
               </div>
               <ChevronRight size={18} className="text-on-surface-variant" />
             </Card>
             <Card className="flex items-center justify-between p-3 border-l-4 border-red-500">
               <div className="flex items-center gap-3">
                 <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center text-red-600">
                   <ShieldAlert size={20} />
                 </div>
                 <div>
                   <p className="text-sm font-bold text-on-surface">12 Câu hỏi bị báo lỗi</p>
                   <p className="text-[10px] text-on-surface-variant font-medium">Cần kiểm tra nội dung</p>
                 </div>
               </div>
               <ChevronRight size={18} className="text-on-surface-variant" />
             </Card>
          </div>
        </section>

        {/* Quick Access Grid */}
        <section className="space-y-4">
          <h2 className="text-sm font-black text-primary uppercase tracking-widest pl-1">Truy cập nhanh</h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action, idx) => (
              <button 
                key={idx}
                onClick={() => setScreen(action.screen)}
                className="bg-white p-4 rounded-2xl shadow-soft border border-surface flex flex-col items-center gap-3 active:bg-surface-variant/20 transition-all group outline-none"
              >
                <div className="w-12 h-12 bg-primary/5 rounded-full flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <action.icon size={24} />
                </div>
                <span className="text-xs font-extrabold text-on-surface text-center tracking-tight leading-tight">{action.label}</span>
              </button>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};
