import React from 'react';
import { 
  GraduationCap, 
  Mail, 
  Phone, 
  Award, 
  TrendingUp, 
  ShieldAlert 
} from 'lucide-react';
import { Header, Card, Badge } from './Shared';
import { User } from '@/src/types';

export const UserDetailScreen = ({ 
  user, 
  onBack, 
  onEdit 
}: { 
  user: User, 
  onBack: () => void, 
  onEdit: () => void 
}) => {
  return (
    <div className="pb-24">
      <Header title="Chi tiết tài khoản" showBack onBack={onBack} />
      
      <div className="p-6 text-center space-y-4">
        <div className="relative inline-block">
          <div className="w-24 h-24 bg-primary/10 rounded-[2.5rem] mx-auto flex items-center justify-center text-primary border-4 border-white shadow-soft font-bold text-3xl">
            {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover rounded-[2.5rem]" /> : user.name.charAt(0)}
          </div>
          <div className="absolute bottom-0 right-0 bg-white p-1.5 rounded-full shadow-md">
            <Badge status={user.status} />
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-black text-primary tracking-tight">{user.name}</h2>
          <p className="text-sm font-bold text-on-surface-variant uppercase tracking-widest mt-1">{user.role}</p>
        </div>
      </div>

      <main className="px-4 space-y-6">
        <section className="space-y-3">
          <h3 className="text-[10px] font-black text-primary uppercase tracking-[0.2em] pl-1 opacity-60">Thông tin cơ bản</h3>
          <Card className="space-y-4">
            <div className="flex gap-4">
              <Mail className="text-on-surface-variant" size={18} />
              <div className="flex-1">
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Email</p>
                <p className="text-sm font-bold">{user.email}</p>
              </div>
            </div>
            <div className="flex gap-4">
              <Phone className="text-on-surface-variant" size={18} />
              <div className="flex-1">
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Số điện thoại</p>
                <p className="text-sm font-bold">{user.phone}</p>
              </div>
            </div>
            <div className="flex gap-4">
              <GraduationCap className="text-on-surface-variant" size={18} />
              <div className="flex-1">
                <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Lớp / Bộ môn</p>
                <p className="text-sm font-bold">{user.role === 'STUDENT' ? (user.class || 'N/A') : user.role === 'TEACHER' ? (user.subject || 'N/A') : 'Quản trị viên'}</p>
              </div>
            </div>
          </Card>
        </section>

        {user.role === 'STUDENT' && (
          <section className="space-y-3">
            <h3 className="text-[10px] font-black text-primary uppercase tracking-[0.2em] pl-1 opacity-60">Thống kê học tập</h3>
            <div className="grid grid-cols-2 gap-3">
              <Card className="flex flex-col gap-1 items-center py-5">
                <Award size={24} className="text-yellow-600 mb-1" />
                <p className="text-xl font-black text-primary">{user.avgScore || 0}</p>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase">Điểm trung bình</p>
              </Card>
              <Card className="flex flex-col gap-1 items-center py-5">
                <TrendingUp size={24} className="text-green-600 mb-1" />
                <p className="text-xl font-black text-primary">{user.completion || 0}%</p>
                <p className="text-[10px] font-bold text-on-surface-variant uppercase">Tiến độ tổng</p>
              </Card>
            </div>
          </section>
        )}

        <section className="pt-4 space-y-3">
          <button 
            onClick={onEdit}
            className="w-full bg-white border-2 border-surface text-primary py-4 rounded-2xl font-bold flex items-center justify-center gap-3 active:bg-surface-variant/20 transition-all outline-none"
          >
            Chỉnh sửa thông tin
          </button>
          <button className="w-full bg-red-50 text-red-600 py-4 rounded-2xl font-bold flex items-center justify-center gap-3 active:opacity-70 transition-all outline-none">
            <ShieldAlert size={18} />
            Khóa tài khoản
          </button>
        </section>
      </main>
    </div>
  )
};
