import React from 'react';
import { GraduationCap, LogOut, Clock, ShieldAlert, Bell, ChevronRight } from 'lucide-react';
import { Header, Card } from './Shared';
import { cn } from '@/src/lib/utils';

export const LoginScreen = ({ onLogin }: { onLogin: () => void }) => (
  <div className="min-h-screen bg-surface flex flex-col p-8 justify-center">
    <div className="mb-12 text-center">
      <div className="w-20 h-20 bg-primary rounded-[2rem] mx-auto mb-6 flex items-center justify-center shadow-card rotate-3">
        <GraduationCap size={48} className="text-white -rotate-3" />
      </div>
      <h1 className="text-3xl font-extrabold text-primary tracking-tight mb-2">Smart Learn</h1>
      <p className="text-on-surface-variant font-medium">Hệ thống quản trị viên</p>
    </div>

    <div className="space-y-6">
      <div className="space-y-1.5">
        <label className="text-xs font-bold text-primary ml-1 uppercase tracking-wider">Tên đăng nhập / Email</label>
        <input 
          type="text" 
          placeholder="admin@smartlearn.com" 
          className="w-full bg-white border-2 border-surface focus:border-primary/20 rounded-2xl p-4 font-medium transition-all focus:ring-0 outline-none"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-bold text-primary ml-1 uppercase tracking-wider">Mật khẩu</label>
        <input 
          type="password" 
          placeholder="••••••••" 
          className="w-full bg-white border-2 border-surface focus:border-primary/20 rounded-2xl p-4 font-medium transition-all focus:ring-0 outline-none"
        />
      </div>

      <div className="flex items-center justify-between px-1">
        <label className="flex items-center gap-2 cursor-pointer group">
          <input type="checkbox" className="w-4 h-4 rounded border-2 border-surface text-primary focus:ring-0" />
          <span className="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors">Ghi nhớ</span>
        </label>
        <button className="text-xs font-bold text-primary hover:underline">Quên mật khẩu?</button>
      </div>

      <button 
        onClick={onLogin}
        className="w-full bg-gradient-to-br from-primary to-primary-container text-white py-4 rounded-2xl font-bold text-lg shadow-card active:scale-[0.98] transition-all"
      >
        Đăng nhập
      </button>
    </div>
  </div>
);

export const SettingsScreen = ({ onLogout }: { onLogout: () => void }) => (
  <div className="pb-24">
    <Header title="Cài đặt hệ thống" />
    <main className="p-4 space-y-2">
       {[
         { label: 'Cấu hình thời gian thi', icon: Clock },
         { label: 'Quản lý Phân quyền', icon: ShieldAlert },
         { label: 'Gửi Thông báo Push', icon: Bell },
         { label: 'Đăng xuất', icon: LogOut, color: 'text-red-500' },
       ].map((item, idx) => (
         <Card key={idx} className="flex items-center justify-between p-4" onClick={item.label === 'Đăng xuất' ? onLogout : undefined}>
            <div className="flex items-center gap-4">
              <div className={cn("p-2 rounded-xl bg-surface", item.color)}>
                <item.icon size={20} />
              </div>
              <span className={cn("text-sm font-bold", item.color || "text-on-surface")}>{item.label}</span>
            </div>
            <ChevronRight size={18} className="text-on-surface-variant opacity-30" />
         </Card>
       ))}
    </main>
  </div>
);
