/**
 * Types and Enums for THPT Smart Learn Admin
 */

export enum AdminTab {
    DASHBOARD = 'overview',
    USERS = 'users',
    CONTENT = 'content',
    REPORTS = 'reports',
    SETTINGS = 'settings'
}

export type Screen = 
    | 'login'
    | 'dashboard'
    | 'user_list'
    | 'user_detail'
    | 'user_form'
    | 'class_list'
    | 'subject_list'
    | 'doc_list'
    | 'doc_form'
    | 'exam_list'
    | 'exam_form'
    | 'question_bank'
    | 'question_form'
    | 'result_list'
    | 'result_detail';

export interface User {
    id: string;
    name: string;
    email: string;
    phone: string;
    role: 'STUDENT' | 'TEACHER' | 'ADMIN';
    status: 'ACTIVE' | 'LOCKED' | 'PENDING';
    avatar?: string;
    class?: string;
    subject?: string;
    avgScore?: number;
    completion?: number;
    docsCount?: number;
    examCount?: number;
    createdAt: string;
}

export interface Document {
    id: string;
    title: string;
    subject: string;
    type: 'PDF' | 'VIDEO' | 'LINK' | 'DOC';
    author: string;
    status: 'PUBLISHED' | 'DRAFT' | 'PENDING';
    views: number;
    downloads: number;
    updatedAt: string;
}

export interface Exam {
    id: string;
    title: string;
    subject: string;
    questionsCount: number;
    duration: number;
    difficulty: 'EASY' | 'MEDIUM' | 'HARD';
    attempts: number;
    status: 'PUBLISHED' | 'DRAFT' | 'LOCKED';
}

export interface Question {
    id: string;
    content: string;
    subject: string;
    topic: string;
    difficulty: 'EASY' | 'MEDIUM' | 'HARD';
    correctAnswer: string;
    status: 'APPROVED' | 'PENDING' | 'ERROR';
}
