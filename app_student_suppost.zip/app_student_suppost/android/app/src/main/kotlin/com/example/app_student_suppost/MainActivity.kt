package com.example.app_student_suppost

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
