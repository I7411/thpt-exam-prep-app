# app_student_suppost

## Tổng quan

Đây là một ứng dụng Flutter cơ bản được tạo từ Flutter starter template. Ứng dụng hiện tại là một demo ứng dụng đếm số (counter app) có chức năng tăng giá trị khi nhấn nút. Project này phục vụ mục đích học tập hoặc làm nền tảng để phát triển các tính năng thực tế liên quan đến hỗ trợ sinh viên (dựa trên tên gọi "app_student_suppost").

## Tính năng

- ✅ Ứng dụng đếm số cơ bản (Counter App)
- ✅ Giao diện Material Design với màu sắc Deep Purple
- ✅ Nút Floating Action Button để tăng giá trị bộ đếm
- ✅ Hot reload support cho quá trình phát triển

## Tech Stack

| Công nghệ | Phiên bản | Mô tả |
|-----------|----------|--------|
| Flutter | Latest | Framework UI |
| Dart | ^3.10.7 | Ngôn ngữ lập trình |
| cupertino_icons | ^1.0.8 | Material Icons font |
| flutter_lints | ^6.0.0 | Lint rules cho Flutter |
| flutter_test | SDK | Framework test cho widget |

## Cấu trúc dự án

```
app_student_suppost/
├── lib/
│   └── main.dart                 # Entry point, chứa MyApp (root) và MyHomePage
├── test/
│   └── widget_test.dart          # Widget test cho counter app
├── android/                       # Native code cho Android
├── ios/                           # Native code cho iOS
├── web/                           # Hỗ trợ web platform
├── windows/                       # Hỗ trợ Windows platform
├── macos/                         # Hỗ trợ macOS platform
├── linux/                         # Hỗ trợ Linux platform
├── pubspec.yaml                  # Dart package manifest
├── analysis_options.yaml         # Linter configuration
└── README.md                      # File này
```

## Yêu cầu hệ thống

- **Dart SDK**: >= 3.10.7
- **Flutter**: Phiên bản ổn định mới nhất
- **Android**: Android SDK 21+ (nếu build cho Android)
- **iOS**: iOS 11+ (nếu build cho iOS)

## Cài đặt

### 1. Clone repository
```bash
git clone <repository-url>
cd app_student_suppost
```

### 2. Cài đặt dependencies
```bash
flutter pub get
```

### 3. Kiểm tra cấu hình Flutter
```bash
flutter doctor
```

## Chạy ứng dụng

### Chạy trên emulator/device Android
```bash
flutter run
```

### Chạy trên iOS simulator
```bash
flutter run -d ios
```

### Chạy trên web
```bash
flutter run -d chrome
```

### Chạy trên Windows
```bash
flutter run -d windows
```

### Chạy trên macOS
```bash
flutter run -d macos
```

### Chạy trên Linux
```bash
flutter run -d linux
```

## Build

### Build APK cho Android
```bash
flutter build apk
```

### Build App Bundle cho Android (Google Play)
```bash
flutter build appbundle
```

### Build cho iOS
```bash
flutter build ios
```

### Build để submit lên App Store
```bash
flutter build ios --release
```

### Build web
```bash
flutter build web
```

### Build Windows
```bash
flutter build windows
```

### Build macOS
```bash
flutter build macos
```

### Build Linux
```bash
flutter build linux
```

## Testing

### Chạy tất cả tests
```bash
flutter test
```

### Chạy test với output chi tiết
```bash
flutter test -v
```

### Chạy test coverage
```bash
flutter test --coverage
```

## Cấu hình

### Material Design
Project đã kích hoạt Material Design (`uses-material-design: true` trong `pubspec.yaml`).

### Color Scheme
Ứng dụng sử dụng Material 3 color scheme với seed color là `Colors.deepPurple`. Để thay đổi, chỉnh sửa giá trị `seedColor` trong file `lib/main.dart`.

### Assets và Fonts
Hiện tại project không sử dụng assets hoặc custom fonts. Để thêm:
- Tạo thư mục `assets/` hoặc `assets/images/`
- Khai báo trong phần `flutter` của `pubspec.yaml`:
```yaml
flutter:
  assets:
    - assets/images/
  fonts:
    - family: CustomFont
      fonts:
        - asset: assets/fonts/CustomFont.ttf
```

## Architecture Notes

### State Management
- **Hiện tại**: Sử dụng `setState()` cơ bản (StatefulWidget)
- **Nhận xét**: Phù hợp cho ứng dụng đơn giản. Nếu phát triển các tính năng phức tạp, xem xét sử dụng:
  - Provider
  - BLoC/Cubit
  - Riverpod
  - GetX

### Routing/Navigation
- **Hiện tại**: Không sử dụng routing phức tạp, chỉ có một home page
- **Nhận xét**: Để mở rộng với multiple screens, sử dụng:
  - MaterialApp.router()
  - GoRouter package
  - Hoặc Navigator 2.0

### UI Framework
- Sử dụng **Material Design** với Widgets cơ bản (Scaffold, AppBar, FloatingActionButton, Column)
- Không sử dụng custom widgets phức tạp

## Luồng chạy ứng dụng (Application Flow)

1. `void main()` → Khởi động ứng dụng
2. `MyApp` (StatelessWidget) → Root widget, thiết lập MaterialApp
3. `MyHomePage` (StatefulWidget) → Trang chủ, quản lý state bộ đếm
4. Khi nhấn FAB → Gọi `_incrementCounter()`
5. `setState()` → Trigger rebuild, cập nhật counter value

## Known Limitations / Missing Information

### Không xác định từ source code:
- ❌ Mục đích thực tế của "app_student_suppost" là gì (chỉ có tên, không có tài liệu)
- ❌ Backend API/Database nếu cần
- ❌ Authentication/Authorization
- ❌ Cấu hình Firebase hoặc dịch vụ cloud khác
- ❌ Environment variables (.env file)
- ❌ Cấu hình build environment-specific
- ❌ Custom assets (ảnh, icons, fonts)
- ❌ HTTP client hoặc API integration
- ❌ Advanced state management (Provider, BLoC, etc.)
- ❌ Advanced navigation (GoRouter, etc.)
- ❌ Comprehensive test suite

### Nhận xét:
- Project hiện tại là **template mẫu của Flutter**, chưa có chức năng thực tế
- Để hoàn thành tính năng "student support", cần thêm nhiều package và logic xử lý

## Contributing

Để contribute vào project, hãy:
1. Fork repository
2. Tạo branch mới cho feature hoặc fix của bạn
3. Commit changes với message rõ ràng
4. Push lên branch của bạn
5. Tạo Pull Request

## License

Chưa được xác định từ source code. Hãy thêm file LICENSE hoặc cập nhật README nếu có license cụ thể.

## Tài liệu hữu ích

- [Flutter Documentation](https://docs.flutter.dev/)
- [Dart Documentation](https://dart.dev/)
- [Flutter Cookbook](https://docs.flutter.dev/cookbook)
- [Material Design Guidelines](https://material.io/design)
