/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  School, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  User, 
  Phone, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle, 
  AlertCircle,
  RefreshCcw,
  BadgeCheck,
  LayoutDashboard,
  LogOut,
  ChevronDown
} from 'lucide-react';

type Role = 'student' | 'teacher' | 'admin';

type Screen = 
  | 'splash' 
  | 'login' 
  | 'register' 
  | 'forgot-password' 
  | 'verify-otp' 
  | 'reset-password' 
  | 'login-failed' 
  | 'dashboard';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [role, setRole] = useState<Role>('student');
  const [transitionDirection, setTransitionDirection] = useState<'left' | 'right'>('right');

  useEffect(() => {
    if (currentScreen === 'splash') {
      const timer = setTimeout(() => {
        setTransitionDirection('right');
        setCurrentScreen('login');
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [currentScreen]);

  const navigateTo = (screen: Screen, direction: 'left' | 'right' = 'right') => {
    setTransitionDirection(direction);
    setCurrentScreen(screen);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-0 md:p-6 bg-gray-100 overflow-hidden">
      {/* Mobile Frame Container */}
      <div 
        className="relative bg-white shadow-2xl overflow-hidden w-full max-w-[390px] h-screen md:h-[844px] md:rounded-[40px] md:border-[8px] md:border-gray-900"
        id="mobile-frame"
      >
        <AnimatePresence mode="wait" initial={false} custom={transitionDirection}>
          {currentScreen === 'splash' && <SplashScreen key="splash" />}
          {currentScreen === 'login' && (
            <LoginScreen 
              key="login" 
              onNavigate={navigateTo} 
              onLoginSuccess={(r) => {
                setRole(r);
                navigateTo('dashboard');
              }}
              onLoginFail={() => navigateTo('login-failed')}
            />
          )}
          {currentScreen === 'register' && <RegisterScreen key="register" onNavigate={navigateTo} />}
          {currentScreen === 'forgot-password' && <ForgotPasswordScreen key="forgot-password" onNavigate={navigateTo} />}
          {currentScreen === 'verify-otp' && <VerifyOTPScreen key="verify-otp" onNavigate={navigateTo} />}
          {currentScreen === 'reset-password' && <ResetPasswordScreen key="reset-password" onNavigate={navigateTo} />}
          {currentScreen === 'login-failed' && <LoginFailedScreen key="login-failed" onNavigate={navigateTo} />}
          {currentScreen === 'dashboard' && <Dashboard role={role} onLogout={() => navigateTo('login', 'left')} />}
        </AnimatePresence>

        {/* Home Indicator (Mock) */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-black/10 rounded-full hidden md:block"></div>
      </div>
    </div>
  );
}

// --- SUB-COMPONENTS ---

function SplashScreen() {
  return (
    <motion.div 
      className="absolute inset-0 primary-gradient flex flex-col items-center justify-center text-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div 
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="w-24 h-24 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center mb-6"
      >
        <School size={48} className="text-white" strokeWidth={1.5} />
      </motion.div>
      <motion.h1 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.8 }}
        className="font-display text-3xl font-extrabold tracking-tight text-center"
      >
        THPT Smart Learn
      </motion.h1>
      <motion.p 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
        className="font-sans text-white/70 mt-2 text-sm"
      >
        Vững bước tương lai
      </motion.p>
      
      <div className="absolute bottom-12 flex space-x-2">
        <motion.div 
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="w-2 h-2 bg-white rounded-full"
        />
        <motion.div 
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }}
          className="w-2 h-2 bg-white rounded-full"
        />
        <motion.div 
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ repeat: Infinity, duration: 1.5, delay: 0.4 }}
          className="w-2 h-2 bg-white rounded-full"
        />
      </div>
    </motion.div>
  );
}

function LoginScreen({ 
  onNavigate, 
  onLoginSuccess, 
  onLoginFail 
}: { 
  onNavigate: (s: Screen, d?: 'left' | 'right') => void, 
  onLoginSuccess: (role: Role) => void,
  onLoginFail: () => void
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>('student');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: typeof errors = {};
    if (!email) newErrors.email = 'Vui lòng nhập email hoặc số điện thoại';
    if (!password) newErrors.password = 'Vui lòng nhập mật khẩu';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      if (email === 'admin' || password === '123') {
         onLoginSuccess(role);
      } else {
         onLoginFail();
      }
    }, 1500);
  };

  return (
    <ScreenContainer>
      <div className="text-center mb-10 pt-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-navy/5 text-navy mb-4">
          <School size={32} />
        </div>
        <h2 className="font-display text-2xl font-bold text-navy">Đăng nhập</h2>
        <p className="text-gray-500 text-sm mt-1">Tiếp tục hành trình học tập của bạn</p>
      </div>

      <form onSubmit={handleLogin} className="space-y-5">
        <Input 
          label="Email hoặc số điện thoại" 
          placeholder="Nhập email hoặc SĐT" 
          icon={<User size={20} />} 
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={errors.email}
        />
        
        <Input 
          label="Mật khẩu" 
          placeholder="Nhập mật khẩu" 
          type={showPassword ? 'text' : 'password'}
          icon={<Lock size={20} />} 
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errors.password}
          trailingIcon={
            <button type="button" onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          }
        />

        <div className="bg-gray-50 p-1 rounded-xl flex gap-1">
          {(['student', 'teacher', 'admin'] as Role[]).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                role === r 
                  ? 'bg-white text-navy shadow-sm' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {r === 'student' ? 'Học sinh' : r === 'teacher' ? 'Giáo viên' : 'Quản trị'}
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between px-1">
          <label className="flex items-center gap-2 cursor-pointer group">
            <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-navy focus:ring-navy" />
            <span className="text-xs text-gray-500 group-hover:text-gray-700">Ghi nhớ đăng nhập</span>
          </label>
          <button 
            type="button"
            onClick={() => onNavigate('forgot-password')}
            className="text-xs font-semibold text-navy hover:underline"
          >
            Quên mật khẩu?
          </button>
        </div>

        <button 
          disabled={loading}
          className="w-full primary-gradient text-white py-4 rounded-full font-display font-bold text-lg shadow-lg shadow-navy/20 hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          {loading ? (
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
            >
              <RefreshCcw size={20} />
            </motion.div>
          ) : (
            <>
              Đăng nhập
              <ArrowRight size={20} />
            </>
          )}
        </button>
      </form>

      <div className="mt-auto pb-8 text-center">
        <p className="text-sm text-gray-500">
          Chưa có tài khoản? 
          <button 
            onClick={() => onNavigate('register')}
            className="ml-1 font-bold text-navy hover:underline"
          >
            Đăng ký ngay
          </button>
        </p>
      </div>
    </ScreenContainer>
  );
}

function RegisterScreen({ onNavigate }: { onNavigate: (s: Screen, d?: 'left' | 'right') => void }) {
  const [role, setRole] = useState<Role>('student');
  return (
    <ScreenContainer scrollable>
      <div className="pt-4 mb-8">
        <button onClick={() => onNavigate('login', 'left')} className="p-2 -ml-2 text-gray-400 hover:text-navy">
          <ArrowLeft size={24} />
        </button>
      </div>

      <div className="mb-8">
        <h2 className="font-display text-2xl font-bold text-navy">Tạo tài khoản</h2>
        <p className="text-gray-500 text-sm mt-1">Gia nhập cộng đồng học tập thông minh</p>
      </div>

      <form className="space-y-4">
        <Input label="Họ và tên" placeholder="Nhập họ và tên" icon={<User size={20} />} />
        <Input label="Email" placeholder="example@mail.com" type="email" icon={<Mail size={20} />} />
        <Input label="Số điện thoại" placeholder="0xxx xxx xxx" type="tel" icon={<Phone size={20} />} />
        
        <div className="space-y-1.5">
          <label className="text-sm font-semibold text-gray-700 ml-1">Vai trò</label>
          <div className="relative">
            <select 
              value={role} 
              onChange={(e) => setRole(e.target.value as Role)}
              className="w-full bg-gray-50 border-0 rounded-xl py-3.5 pl-4 pr-10 text-sm focus:ring-1 focus:ring-navy/30 appearance-none transition-all"
            >
              <option value="student">Học sinh</option>
              <option value="teacher">Giáo viên</option>
            </select>
            <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
          </div>
        </div>

        {role === 'student' && (
          <div className="space-y-1.5">
            <label className="text-sm font-semibold text-gray-700 ml-1">Lớp</label>
            <div className="relative">
              <select className="w-full bg-gray-50 border-0 rounded-xl py-3.5 pl-4 pr-10 text-sm focus:ring-1 focus:ring-navy/30 appearance-none transition-all">
                <option value="">Chọn lớp của bạn</option>
                <option value="12A1">12A1</option>
                <option value="12A2">12A2</option>
                <option value="12A3">12A3</option>
              </select>
              <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
          </div>
        )}

        <Input label="Mật khẩu" placeholder="••••••••" type="password" icon={<Lock size={20} />} />
        <Input label="Xác nhận mật khẩu" placeholder="••••••••" type="password" icon={<Lock size={20} />} />

        <div className="flex items-start gap-3 py-2">
          <input type="checkbox" className="mt-1 w-4 h-4 rounded border-gray-300 text-navy focus:ring-navy" />
          <p className="text-xs text-gray-500 leading-relaxed">
            Tôi đồng ý với <span className="text-navy font-semibold underline">điều khoản sử dụng</span> và <span className="text-navy font-semibold underline">chính sách bảo mật</span>
          </p>
        </div>

        <button 
          type="button"
          onClick={() => onNavigate('login')}
          className="w-full primary-gradient text-white py-4 rounded-full font-display font-bold text-lg shadow-lg shadow-navy/20 hover:opacity-90 active:scale-[0.98] transition-all"
        >
          Đăng ký
        </button>
      </form>

      <div className="mt-8 pb-8 text-center">
        <p className="text-sm text-gray-500">
          Đã có tài khoản? 
          <button 
            onClick={() => onNavigate('login', 'left')}
            className="ml-1 font-bold text-navy hover:underline"
          >
            Đăng nhập
          </button>
        </p>
      </div>
    </ScreenContainer>
  );
}

function ForgotPasswordScreen({ onNavigate }: { onNavigate: (s: Screen, d?: 'left' | 'right') => void }) {
  return (
    <ScreenContainer>
      <div className="pt-4 mb-20">
        <button onClick={() => onNavigate('login', 'left')} className="p-2 -ml-2 text-gray-400 hover:text-navy">
          <ArrowLeft size={24} />
        </button>
      </div>

      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-navy/5 text-navy mb-6">
          <Lock size={40} />
        </div>
        <h2 className="font-display text-2xl font-bold text-navy">Quên mật khẩu?</h2>
        <p className="text-gray-500 text-sm mt-2 max-w-[250px] mx-auto">
          Nhập email hoặc số điện thoại của bạn để nhận mã khôi phục
        </p>
      </div>

      <form className="space-y-6">
        <Input label="Email hoặc SĐT" placeholder="example@mail.com" icon={<Mail size={20} />} />
        
        <button 
          type="button"
          onClick={() => onNavigate('verify-otp')}
          className="w-full primary-gradient text-white py-4 rounded-full font-display font-bold text-lg shadow-lg shadow-navy/20 hover:opacity-90 active:scale-[0.98] transition-all"
        >
          Tiếp tục
        </button>
      </form>

      <div className="mt-auto pb-12 text-center">
        <button 
          onClick={() => onNavigate('login', 'left')}
          className="text-sm font-bold text-navy hover:underline"
        >
          Quay lại đăng nhập
        </button>
      </div>
    </ScreenContainer>
  );
}

function VerifyOTPScreen({ onNavigate }: { onNavigate: (s: Screen, d?: 'left' | 'right') => void }) {
  return (
    <ScreenContainer>
      <div className="pt-4 mb-20">
        <button onClick={() => onNavigate('forgot-password', 'left')} className="p-2 -ml-2 text-gray-400 hover:text-navy">
          <ArrowLeft size={24} />
        </button>
      </div>

      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-navy/5 text-navy mb-6">
          <BadgeCheck size={40} />
        </div>
        <h2 className="font-display text-2xl font-bold text-navy">Xác thực OTP</h2>
        <p className="text-gray-500 text-sm mt-2 max-w-[280px] mx-auto">
          Mã xác thực đã được gửi đến <span className="text-navy font-bold">tam***@gmail.com</span>
        </p>
      </div>

      <div className="flex justify-between gap-3 mb-10">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <input 
            key={i}
            type="text" 
            maxLength={1}
            className="w-11 h-12 bg-gray-50 border-0 rounded-xl text-center font-display text-xl font-bold focus:ring-1 focus:ring-navy/30 transition-all"
            defaultValue={i < 4 ? Math.floor(Math.random() * 10) : ''}
          />
        ))}
      </div>

      <div className="text-center mb-8">
        <p className="text-xs text-gray-400 mb-2">Không nhận được mã?</p>
        <button className="text-sm font-bold text-navy hover:underline flex items-center justify-center gap-1 mx-auto">
          <RefreshCcw size={14} />
          Gửi lại mã (01:59)
        </button>
      </div>

      <button 
        type="button"
        onClick={() => onNavigate('reset-password')}
        className="w-full primary-gradient text-white py-4 rounded-full font-display font-bold text-lg shadow-lg shadow-navy/20 hover:opacity-90 active:scale-[0.98] transition-all"
      >
        Xác nhận
      </button>
    </ScreenContainer>
  );
}

function ResetPasswordScreen({ onNavigate }: { onNavigate: (s: Screen, d?: 'left' | 'right') => void }) {
  return (
    <ScreenContainer>
      <div className="pt-4 mb-16">
        <button onClick={() => onNavigate('verify-otp', 'left')} className="p-2 -ml-2 text-gray-400 hover:text-navy">
          <ArrowLeft size={24} />
        </button>
      </div>

      <div className="mb-10">
        <h2 className="font-display text-2xl font-bold text-navy tracking-tight">Đặt lại mật khẩu</h2>
        <p className="text-gray-500 text-sm mt-1">Tạo mật khẩu mới an toàn và dễ nhớ</p>
      </div>

      <form className="space-y-6">
        <Input label="Mật khẩu mới" placeholder="••••••••" type="password" icon={<Lock size={20} />} />
        
        <div className="space-y-2">
          <div className="flex gap-1 h-1.5 px-0.5">
            <div className="flex-1 rounded-full bg-orange-400"></div>
            <div className="flex-1 rounded-full bg-orange-400"></div>
            <div className="flex-1 rounded-full bg-gray-200"></div>
            <div className="flex-1 rounded-full bg-gray-200"></div>
          </div>
          <p className="text-[10px] font-bold text-orange-500 uppercase flex justify-end">Mật khẩu trung bình</p>
        </div>

        <Input label="Xác nhận mật khẩu" placeholder="••••••••" type="password" icon={<Lock size={20} />} />
        
        <button 
          type="button"
          onClick={() => onNavigate('login')}
          className="w-full primary-gradient text-white py-4 rounded-full font-display font-bold text-lg shadow-lg shadow-navy/20 hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          Cập nhật mật khẩu
          <CheckCircle size={20} />
        </button>
      </form>
    </ScreenContainer>
  );
}

function LoginFailedScreen({ onNavigate }: { onNavigate: (s: Screen, d?: 'left' | 'right') => void }) {
  return (
    <ScreenContainer>
      <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-24 h-24 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-8"
        >
          <AlertCircle size={48} />
        </motion.div>
        
        <h2 className="font-display text-2xl font-bold text-navy mb-3">Đăng nhập thất bại</h2>
        <p className="text-gray-500 text-sm leading-relaxed mb-12">
          Tài khoản hoặc mật khẩu không đúng. Vui lòng kiểm tra lại thông tin đăng nhập của bạn.
        </p>

        <div className="w-full space-y-4">
          <button 
            onClick={() => onNavigate('login', 'left')}
            className="w-full primary-gradient text-white py-4 rounded-full font-display font-bold text-lg shadow-lg shadow-navy/20 transition-all active:scale-95"
          >
            Thử lại
          </button>
          
          <button 
            onClick={() => onNavigate('forgot-password')}
            className="w-full py-2 text-sm font-bold text-navy hover:underline"
          >
            Quên mật khẩu?
          </button>
        </div>
      </div>
    </ScreenContainer>
  );
}

function Dashboard({ role, onLogout }: { role: Role, onLogout: () => void }) {
  return (
    <ScreenContainer scrollable>
      <header className="flex items-center justify-between pt-8 mb-8">
        <div>
          <h2 className="font-display text-xl font-bold text-navy">
            Chào mừng, {role === 'student' ? 'Học sinh' : role === 'teacher' ? 'Giáo viên' : 'Admin'}!
          </h2>
          <p className="text-gray-500 text-xs">Chúc bạn một ngày học tập hiệu quả</p>
        </div>
        <button onClick={onLogout} className="p-2 text-gray-400 hover:text-red-500 transition-colors">
          <LogOut size={20} />
        </button>
      </header>

      <div className="grid grid-cols-2 gap-4">
        {[
          { label: 'Bài giảng', color: 'bg-blue-50 text-blue-600', icon: <School size={24} /> },
          { label: 'Kiểm tra', color: 'bg-orange-50 text-orange-600', icon: <BadgeCheck size={24} /> },
          { label: 'Tài liệu', color: 'bg-purple-50 text-purple-600', icon: <Mail size={24} /> },
          { label: 'Thông báo', color: 'bg-green-50 text-green-600', icon: <LayoutDashboard size={24} /> },
        ].map((item, i) => (
          <div key={i} className={`p-4 rounded-3xl ${item.color} flex flex-col gap-4 shadow-sm border border-transparent hover:border-current/10 transition-all cursor-pointer`}>
            {item.icon}
            <span className="font-bold text-sm">{item.label}</span>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <h3 className="font-display font-bold text-navy mb-4">Hoạt động gần đây</h3>
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-gray-50 p-4 rounded-2xl flex items-center gap-4">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-navy shadow-sm">
                <CheckCircle size={18} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold text-gray-800">Hoàn thành bài tập Toán</p>
                <p className="text-[10px] text-gray-400">2 giờ trước • Tiết 3 - Giải tích 12</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </ScreenContainer>
  );
}

// --- SHARED UI ---

function ScreenContainer({ children, scrollable = false }: { children: React.ReactNode, scrollable?: boolean }) {
  return (
    <motion.div 
      initial={{ x: 20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: -20, opacity: 0 }}
      transition={{ duration: 0.4, ease: "anticipate" }}
      className={`absolute inset-0 px-6 flex flex-col ${scrollable ? 'overflow-y-auto scrollbar-hide' : 'overflow-hidden'}`}
    >
      {children}
    </motion.div>
  );
}

function Input({ 
  label, 
  icon, 
  trailingIcon, 
  error,
  ...props 
}: { 
  label: string, 
  icon?: React.ReactNode, 
  trailingIcon?: React.ReactNode,
  error?: string
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="space-y-1.5 group">
      <label className="text-sm font-semibold text-gray-700 ml-1 transition-colors group-focus-within:text-navy">
        {label}
      </label>
      <div className={`relative rounded-xl overflow-hidden transition-all ${error ? 'ring-1 ring-red-500' : 'focus-within:ring-1 focus-within:ring-navy/30'}`}>
        {icon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-navy transition-colors">
            {icon}
          </div>
        )}
        <input 
          {...props} 
          className={`w-full bg-gray-50 border-0 ${icon ? 'pl-11' : 'pl-4'} ${trailingIcon ? 'pr-11' : 'pr-4'} py-3.5 text-sm font-sans placeholder:text-gray-300 focus:ring-0 focus:bg-white transition-all`}
        />
        {trailingIcon && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
            {trailingIcon}
          </div>
        )}
      </div>
      {error && <p className="text-[10px] font-bold text-red-500 ml-1 uppercase">{error}</p>}
    </div>
  );
}
