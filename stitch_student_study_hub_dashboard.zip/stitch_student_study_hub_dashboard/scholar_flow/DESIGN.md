# Design System Documentation: The Academic Sanctuary

## 1. Overview & Creative North Star
This design system is built to transform the high-pressure environment of exam preparation into a focused, premium, and serene digital space. We are moving away from the "cluttered classroom" aesthetic and toward a **Creative North Star** we call **"The Academic Sanctuary."**

The system rejects the "standard app" look of grids and borders. Instead, it utilizes **Editorial Asymmetry**—where large, authoritative headlines meet generous negative space—to create a sense of calm and organization. By layering surfaces rather than boxing them in, we guide the student’s focus toward what truly matters: their progress and their learning.

---

## 2. Colors & Surface Logic
The palette is rooted in the authority of `primary` (#00236f) and the clarity of `secondary` (#0058be), with `tertiary` (#4b1c00/orange-tinted) used sparingly to spark motivation.

### The "No-Line" Rule
To maintain a high-end editorial feel, **1px solid borders are prohibited for sectioning.** Boundaries must be defined through background color shifts. For example, a `surface-container-low` section should sit directly on a `surface` background to create a logical break without visual noise.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine paper. Use the surface-container tiers to define importance:
*   **Surface:** The base canvas for the entire screen.
*   **Surface-Container-Low:** For secondary content or large grouping areas.
*   **Surface-Container-Lowest (White):** For primary interactive cards and modules to make them "pop" against the greyish backgrounds.
*   **Nesting:** When placing a search bar inside a header, use `surface-container-high` on a `primary` background to create a "recessed" look.

### The Glass & Gradient Rule
To prevent the app from feeling "flat" or "cheap," use **Signature Textures**:
*   **CTAs:** Use a subtle linear gradient from `primary` (#00236f) to `primary_container` (#1e3a8a) at a 135-degree angle.
*   **Floating Navigation:** Apply a `surface_container_lowest` color at 80% opacity with a `20px` backdrop-blur to create a "frosted glass" effect.

---

## 3. Typography
We utilize a dual-font strategy to balance academic authority with modern readability.

*   **Display & Headlines (Manrope):** Chosen for its geometric, sophisticated personality. Use `display-lg` and `headline-md` to create "Editorial Moments"—large, bold headings that anchor the page and provide a sense of confidence.
*   **Body & Titles (Inter):** The workhorse font. Inter’s tall x-height ensures that complex exam questions and long-form explanations remain highly legible even on small mobile screens.
*   **Hierarchy as Identity:** Always lead with a strong headline. A large `headline-lg` greeting should be significantly more prominent than the content below it to establish a clear starting point for the user’s eye.

---

## 4. Elevation & Depth
Depth in this system is achieved through **Tonal Layering** rather than traditional drop shadows.

*   **The Layering Principle:** Instead of shadows, place a `surface-container-lowest` card on a `surface-container-low` background. The slight shift in hex value provides a sophisticated, natural lift.
*   **Ambient Shadows:** For high-priority floating elements (like a "Start Quiz" button), use an extra-diffused shadow: `box-shadow: 0 12px 32px rgba(0, 35, 111, 0.08)`. Notice the shadow is a tinted version of our `primary` color, not black.
*   **The "Ghost Border" Fallback:** If a layout requires a boundary for accessibility, use the `outline_variant` at **15% opacity**. This creates a hint of a container without breaking the "No-Line" rule.
*   **Rounding:** All primary containers must use the `xl` (1.5rem/24px) scale to feel friendly and approachable, while smaller elements like chips use `md` (0.75rem).

---

## 5. Components

### Buttons
*   **Primary:** Rounded-full, featuring the primary-to-primary-container gradient. Text is `on_primary`.
*   **Secondary:** `surface-container-highest` background with `on_surface` text. No border.
*   **Tertiary (Accent):** Reserved for high-alert calls to action (e.g., "Submit Exam"). Uses `tertiary_container` with `on_tertiary_container` text.

### Cards & Progress Modules
*   **Forbid dividers.** Use `body-sm` labels or `surface` shifts to separate information.
*   **Editorial Stats:** When showing exam scores, use `display-sm` for the number to make achievement feel monumental.

### Input Fields
*   **Background:** `surface-container-low`.
*   **Focus State:** Shift background to `surface-container-lowest` and apply a 1px "Ghost Border" using `secondary` at 30% opacity.
*   **Corners:** `rounded-lg` for inputs to provide a slightly more structured feel than the `xl` cards.

### Study Progress (Signature Component)
*   Instead of a thin line, use a thick, `rounded-full` track in `surface-container-highest` with a `secondary` fill. This makes the progress feel tangible and weighty.

---

## 6. Do's and Don'ts

### Do
*   **Do** use extreme vertical spacing. If you think there is enough white space, add 8px more.
*   **Do** use `tertiary` (Orange) only for "moments of joy" or urgent actions.
*   **Do** align text-heavy content to a strict left margin to maintain an editorial grid.

### Don't
*   **Don't** use 100% black (#000000) for text. Use `on_surface` (#191c1d) to reduce eye strain during long study sessions.
*   **Don't** use "Drop Shadows" from standard software defaults. If a shadow doesn't look like light hitting paper, it's too heavy.
*   **Don't** use dividers between list items. Use an 8px or 12px gap instead.
*   **Don't** use sharp corners. Everything is a guest in the "Sanctuary," and sharp corners feel aggressive.

---

**Director's Final Note:** 
This system isn't about "utility"—it's about "empowerment." Every time a student opens this app, they should feel like they are stepping into a clean, well-lit library where success is inevitable. Keep it breathing, keep it layered, and keep it intentional.