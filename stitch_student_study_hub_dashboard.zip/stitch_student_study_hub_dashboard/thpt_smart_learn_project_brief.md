# Project Brief: THPT Smart Learn

## 1. Project Overview
**THPT Smart Learn** is a modern, mobile-first educational ecosystem designed specifically for 12th-grade students in Vietnam. The platform provides a comprehensive suite of tools for national high school exam preparation, bridging the gap between students, teachers, and administrators.

## 2. Core Value Proposition
- **For Students:** A personalized, motivating "Academic Sanctuary" for self-study, mock testing, and progress tracking.
- **For Teachers:** A powerful "Class Insights" dashboard for resource management and data-driven student support.
- **For Admins:** A robust control center for system-wide user, material, and examination oversight.

## 3. Design Philosophy: "Scholar Flow"
The visual identity focuses on creating a "focused sanctuary" through:
- **Calmness:** Deep blues and clean whites to reduce cognitive load.
- **Motivation:** Subtle orange accents for energy and call-to-actions.
- **Modernity:** Soft shadows, rounded corners (8px-24px), and glassmorphic elements.
- **Clarity:** High-contrast typography (Manrope/Inter) and intuitive iconography.

## 4. Key Functional Pillars
### A. Student Experience
- **Personalized Dashboard:** Real-time stats on study hours, GPA, and saved materials.
- **Subject Mastery:** Progress bars and completion tracking for all national exam subjects.
- **Smart Testing:** A focused mock exam environment with timers and instant result analysis.
- **Weak Point Analysis:** Data-driven identification of topics needing review (e.g., Logarithms, English tenses).

### B. Teacher & Admin Infrastructure
- **Resource Repository:** Management of PDFs, videos, and complex question banks.
- **Analytics Engine:** Deep dives into class performance, score distributions, and attendance.
- **Scheduling:** Integrated teaching calendars and exam countdowns.

## 5. Technical Requirements
- **Platform:** Mobile-first (Android/Flutter style), responsive for Web.
- **Language:** Fully localized in Vietnamese.
- **UI System:** Modular components (TopAppBar, BottomNavBar, NavigationDrawer) for consistency.

## 6. Project Status
- **Current Phase:** High-fidelity UI Design & Prototyping.
- **Completed Assets:** Design System (Scholar Flow), Login/Register flows, Student/Teacher/Admin Dashboards, Question Bank management, and Performance Analytics.