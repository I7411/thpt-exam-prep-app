/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Home, 
  Map, 
  Library, 
  PenTool, 
  User, 
  Bell, 
  MessageCircle, 
  ChevronRight, 
  ArrowRight,
  LogOut,
  Settings,
  BookOpen,
  Award,
  Clock,
  Target,
  CheckCircle2,
  XCircle,
  Eye,
  EyeOff,
  Search
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
type Screen = 'SPLASH' | 'ONBOARDING' | 'LOGIN' | 'REGISTER' | 'GOALS' | 'MAIN_APP';
type Tab = 'HOME' | 'ROADMAP' | 'STORE' | 'EXAM' | 'PROFILE';

// --- Shared Components ---

const Button = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  className = '',
  fullWidth = false,
  disabled = false,
  size = 'md'
}: { 
  children: React.ReactNode; 
  onClick?: () => void; 
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'error';
  className?: string;
  fullWidth?: boolean;
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
}) => {
  const baseStyles = "rounded-2xl font-semibold transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50 disabled:active:scale-100";
  
  const sizes = {
    sm: "px-4 py-2 text-xs",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  };

  const variants = {
    primary: "bg-primary text-white shadow-lg shadow-primary/20 hover:bg-primary/95",
    secondary: "bg-secondary text-white shadow-lg shadow-secondary/20 hover:bg-secondary/95",
    outline: "border-2 border-primary text-primary hover:bg-primary/5",
    ghost: "text-slate-600 hover:bg-slate-100",
    error: "bg-error text-white hover:bg-error/95",
  };

  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${sizes[size]} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
    >
      {children}
    </button>
  );
};

const Input = ({ 
  label, 
  type = 'text', 
  placeholder, 
  value, 
  onChange,
  icon: Icon,
  error
}: { 
  label?: string; 
  type?: string; 
  placeholder?: string; 
  value?: string; 
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  icon?: any;
  error?: string;
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const isPassword = type === 'password';
  const effectiveType = isPassword ? (showPassword ? 'text' : 'password') : type;

  return (
    <div className="flex flex-col gap-1.5 w-full">
      {label && <label className="text-sm font-medium text-slate-600 ml-1">{label}</label>}
      <div className="relative group">
        {Icon && <Icon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-primary transition-colors" />}
        <input 
          type={effectiveType}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          className={`w-full bg-slate-50 border-none rounded-2xl py-4 ${Icon ? 'pl-11' : 'pl-4'} pr-12 focus:ring-2 focus:ring-primary/20 transition-all font-sans text-slate-800 placeholder:text-slate-400`}
        />
        {isPassword && (
          <button 
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
        )}
      </div>
      {error && <p className="text-xs text-error mt-0.5 ml-1">{error}</p>}
    </div>
  );
};

const Card = ({ children, className = "", onClick, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div 
    {...props}
    onClick={onClick}
    className={`bg-white rounded-[24px] p-5 shadow-sm border border-slate-100/50 ${onClick ? 'cursor-pointer active:scale-[0.98] transition-all' : ''} ${className}`}
  >
    {children}
  </div>
);

// --- Individual Screens ---

const SplashScreen = ({ onComplete }: { onComplete: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onComplete, 2500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-primary text-white p-8">
      <motion.div 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="mb-8"
      >
        <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center shadow-2xl">
          <BookOpen className="w-12 h-12 text-primary" strokeWidth={3} />
        </div>
      </motion.div>
      <motion.h1 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="text-3xl font-extrabold mb-2 tracking-tight"
      >
        THPT Smart Learn
      </motion.h1>
      <motion.p 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="text-primary-foreground/80 text-center font-medium"
      >
        Ôn thi đúng trọng tâm, tiến bộ mỗi ngày
      </motion.p>
      <div className="absolute bottom-16">
        <div className="flex gap-2">
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 1.5, delay: 0 }}
            className="w-2 h-2 bg-white/40 rounded-full" 
          />
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }}
            className="w-2 h-2 bg-white/40 rounded-full" 
          />
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 1.5, delay: 0.4 }}
            className="w-2 h-2 bg-white/40 rounded-full" 
          />
        </div>
      </div>
    </div>
  );
};

const Onboarding = ({ onFinish }: { onFinish: () => void }) => {
  const [step, setStep] = useState(0);
  const content = [
    {
      title: "Ôn tập theo lộ trình cá nhân",
      desc: "Hệ thống tự động phân tích năng lực và gợi ý nội dung ôn tập phù hợp nhất với bạn.",
      icon: <Target className="w-12 h-12 text-primary" />
    },
    {
      title: "Luyện đề, chấm điểm tức thì",
      desc: "Kho đề thi phong phú, sát với cấu trúc đề chính thức, giúp bạn làm quen với áp lực thi cử.",
      icon: <PenTool className="w-12 h-12 text-secondary" />
    },
    {
      title: "Theo dõi điểm mạnh, điểm yếu",
      desc: "Báo cáo chi tiết từng kỹ năng, giúp bạn tối ưu hóa thời gian học tập hiệu quả nhất.",
      icon: <Award className="w-12 h-12 text-amber-500" />
    }
  ];

  const nextStep = () => {
    if (step < content.length - 1) setStep(step + 1);
    else onFinish();
  };

  return (
    <div className="flex-1 flex flex-col bg-white overflow-hidden p-8">
      <div className="flex justify-end pt-4">
        <button onClick={onFinish} className="text-slate-400 font-semibold hover:text-slate-600 transition-colors">Bỏ qua</button>
      </div>
      
      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <AnimatePresence mode="wait">
          <motion.div 
            key={step}
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -50, opacity: 0 }}
            className="w-full flex flex-col items-center"
          >
            <div className="w-32 h-32 bg-slate-50 rounded-full flex items-center justify-center mb-10">
              {content[step].icon}
            </div>
            <h2 className="text-2xl font-bold mb-4 px-4 leading-tight">{content[step].title}</h2>
            <p className="text-slate-500 max-w-xs">{content[step].desc}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex flex-col gap-8 pb-8 items-center">
        <div className="flex gap-2">
          {content.map((_, i) => (
            <div key={i} className={`h-2 transition-all duration-300 rounded-full ${i === step ? 'w-8 bg-primary' : 'w-2 bg-slate-200'}`} />
          ))}
        </div>
        
        <Button onClick={nextStep} fullWidth variant="primary">
          {step === content.length - 1 ? 'Bắt đầu ngay' : 'Tiếp tục'}
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};

const LoginScreen = ({ onLogin, onRegister }: { onLogin: () => void; onRegister: () => void }) => {
  return (
    <div className="flex-1 flex flex-col bg-white p-8">
      <div className="pt-12 mb-12 flex flex-col items-center">
        <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mb-6 shadow-xl shadow-primary/10">
          <BookOpen className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800">Chào mừng trở lại</h2>
        <p className="text-slate-400 mt-1">Đăng nhập để tiếp tục học tập</p>
      </div>

      <div className="flex flex-col gap-6">
        <Input label="Email hoặc số điện thoại" placeholder="Nhập email/SĐT" icon={User} />
        <Input label="Mật khẩu" type="password" placeholder="Nhập mật khẩu" icon={Target} />
        
        <div className="flex justify-between items-center -mt-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" className="rounded border-slate-300 text-primary focus:ring-primary/20 h-4 w-4" />
            <span className="text-sm text-slate-500 font-medium">Ghi nhớ</span>
          </label>
          <button className="text-sm text-primary font-bold hover:underline">Quên mật khẩu?</button>
        </div>

        <Button onClick={onLogin} fullWidth className="mt-4">Đăng nhập</Button>
        
        <div className="flex items-center gap-4 my-2">
          <div className="flex-1 h-px bg-slate-100" />
          <span className="text-slate-300 text-xs font-bold uppercase tracking-widest">Hoặc</span>
          <div className="flex-1 h-px bg-slate-100" />
        </div>

        <button 
          onClick={onRegister}
          className="py-4 rounded-2xl font-bold text-slate-600 bg-slate-50 hover:bg-slate-100 transition-all border border-slate-200/50"
        >
          Chưa có tài khoản? <span className="text-secondary ml-1">Đăng ký ngay</span>
        </button>
      </div>
    </div>
  );
};

const RegisterScreen = ({ onBack, onSuccess }: { onBack: () => void; onSuccess: () => void }) => {
  return (
    <div className="flex-1 flex flex-col bg-white p-8 overflow-y-auto no-scrollbar">
      <div className="pt-4 mb-10">
        <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight">Tạo tài khoản</h2>
        <p className="text-slate-400 mt-2">Dành cho học sinh lớp 12 chuẩn bị ôn tập</p>
      </div>

      <div className="flex flex-col gap-4">
        <Input label="Họ và tên" placeholder="Nguyễn Văn A" />
        <Input label="Email hoặc số điện thoại" placeholder="email@vi-du.com" />
        <Input label="Lớp" value="Lớp 12" />
        <Input label="Trường học (Tùy chọn)" placeholder="Tên trường của bạn" />
        <Input label="Mật khẩu" type="password" placeholder="Tạo mật khẩu mạnh" />
        <Input label="Xác nhận mật khẩu" type="password" placeholder="Nhập lại mật khẩu" />
        
        <div className="mt-4 flex flex-col gap-4">
          <Button onClick={onSuccess} fullWidth>Tạo tài khoản</Button>
          <button onClick={onBack} className="text-slate-500 text-sm font-semibold hover:text-slate-700 underline underline-offset-4 decoration-2 decoration-slate-200">
            Đã có tài khoản? Quay về đăng nhập
          </button>
        </div>
      </div>
      <div className="h-8" />
    </div>
  );
};

const SetGoalsScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [selectedScore, setSelectedScore] = useState<number | null>(null);
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);

  const subjects = [
    "Toán", "Ngữ văn", "Tiếng Anh", "Vật lý", "Hóa học", "Sinh học", "Lịch sử", "Địa lý", "GDCD"
  ];

  const toggleSubject = (s: string) => {
    if (selectedSubjects.includes(s)) {
      setSelectedSubjects(selectedSubjects.filter(item => item !== s));
    } else {
      setSelectedSubjects([...selectedSubjects, s]);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-white p-8">
      <div className="pt-4 mb-8">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-1 bg-primary rounded-full" />
          <div className="w-8 h-1 bg-slate-100 rounded-full" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800">Mục tiêu của bạn là gì?</h2>
        <p className="text-slate-400 text-sm mt-2 font-medium">Chúng mình sẽ cá nhân hóa lộ trình dựa trên lựa chọn này</p>
      </div>

      <div className="flex flex-col gap-8 flex-1 overflow-y-auto no-scrollbar py-2">
        <section>
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Điểm mục tiêu</h3>
          <div className="grid grid-cols-4 gap-3">
            {[6, 7, 8, 9].map((score) => (
              <button
                key={score}
                onClick={() => setSelectedScore(score)}
                className={`h-14 rounded-2xl flex items-center justify-center text-lg font-bold transition-all ${
                  selectedScore === score 
                    ? 'bg-primary text-white shadow-lg shadow-primary/20 scale-105' 
                    : 'bg-slate-50 text-slate-500 border border-slate-100'
                }`}
              >
                {score}+
              </button>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Môn ôn tập</h3>
          <div className="grid grid-cols-2 gap-3 pb-8">
            {subjects.map((sub) => (
              <button
                key={sub}
                onClick={() => toggleSubject(sub)}
                className={`py-3 px-4 rounded-xl text-sm font-semibold transition-all text-left flex items-center justify-between ${
                  selectedSubjects.includes(sub)
                    ? 'bg-secondary/10 text-secondary border-2 border-secondary'
                    : 'bg-slate-50 text-slate-600 border border-slate-100'
                }`}
              >
                {sub}
                {selectedSubjects.includes(sub) && <CheckCircle2 className="w-4 h-4" />}
              </button>
            ))}
          </div>
        </section>
      </div>

      <div className="pt-6">
        <Button 
          onClick={onComplete} 
          disabled={!selectedScore || selectedSubjects.length === 0} 
          fullWidth
        >
          Tiếp tục
          <ArrowRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};

// --- Main App Components ---

const Header = ({ title }: { title: string }) => (
  <div className="flex justify-between items-center px-6 py-5 bg-white/80 backdrop-blur-md sticky top-0 z-10 border-b border-slate-50">
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
        <BookOpen className="w-5 h-5 text-primary" />
      </div>
      <h1 className="text-lg font-bold text-slate-800">{title}</h1>
    </div>
    <div className="flex items-center gap-2">
      <button className="relative p-2 rounded-full hover:bg-slate-100 transition-colors">
        <Bell className="w-6 h-6 text-slate-500" />
        <span className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full border-2 border-white" />
      </button>
    </div>
  </div>
);

const BottomNav = ({ activeTab, setTab }: { activeTab: Tab; setTab: (t: Tab) => void }) => {
  const tabs: { id: Tab; icon: any; label: string }[] = [
    { id: 'HOME', icon: Home, label: 'Trang chủ' },
    { id: 'ROADMAP', icon: Map, label: 'Lộ trình' },
    { id: 'STORE', icon: Library, label: 'Kho học' },
    { id: 'EXAM', icon: PenTool, label: 'Thi thử' },
    { id: 'PROFILE', icon: User, label: 'Cá nhân' },
  ];

  return (
    <div className="bg-white border-t border-slate-100 px-6 py-4 flex justify-between items-center pb-8 sticky bottom-0 z-20">
      {tabs.map((tab) => (
        <button 
          key={tab.id}
          onClick={() => setTab(tab.id)}
          className={`flex flex-col items-center gap-1 transition-all ${activeTab === tab.id ? 'text-primary' : 'text-slate-400'}`}
        >
          <tab.icon className={`w-6 h-6 ${activeTab === tab.id ? 'fill-primary/10' : ''}`} />
          <span className="text-[10px] font-bold uppercase tracking-tight">{tab.label}</span>
        </button>
      ))}
    </div>
  );
};

const HomeScreen = () => (
  <div className="flex-1 flex flex-col gap-8 p-6 overflow-y-auto no-scrollbar">
    <section>
      <div className="flex items-end justify-between mb-4">
        <div>
          <p className="text-slate-400 text-sm font-medium">Xin chào,</p>
          <h2 className="text-2xl font-bold text-slate-800">Minh Tâm 👋</h2>
        </div>
        <div className="bg-secondary/10 px-3 py-1.5 rounded-full flex items-center gap-2">
          <Target className="w-4 h-4 text-secondary" />
          <span className="text-xs font-bold text-secondary">Học lực: 8.5</span>
        </div>
      </div>
      
      <Card className="bg-primary text-white border-none p-6 overflow-hidden relative">
        <div className="relative z-10">
          <p className="text-primary-foreground/70 text-sm font-medium mb-1">Tiến độ kỳ thi THPT QG</p>
          <h3 className="text-3xl font-black mb-4">Còn 45 ngày</h3>
          <div className="w-full bg-white/20 h-2 rounded-full mb-2">
            <div className="bg-amber-400 h-full w-[70%] rounded-full shadow-[0_0_8px_rgba(251,191,36,0.5)]" />
          </div>
          <p className="text-xs text-primary-foreground/60 font-medium">Bạn đã hoàn thành 70% lộ trình ôn tập</p>
        </div>
        <Target className="absolute -right-6 -bottom-6 w-32 h-32 opacity-10 text-white rotate-12" />
      </Card>
    </section>

    <section>
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold text-slate-800">Nhiệm vụ hôm nay</h3>
        <button className="text-xs font-bold text-primary">Tất cả</button>
      </div>
      <div className="flex flex-col gap-3">
        {[
          { title: 'Giải đề Toán mẫu 2024', subject: 'Toán', time: '60 phút', icon: '📐', color: 'bg-blue-50' },
          { title: 'Học từ vựng Unit 8-10', subject: 'Tiếng Anh', time: '30 phút', icon: '🇬🇧', color: 'bg-purple-50' },
          { title: 'Tóm tắt Sóng - Xuân Quỳnh', subject: 'Ngữ văn', time: '45 phút', icon: '📝', color: 'bg-green-50' },
        ].map((task, i) => (
          <Card key={i} className="p-4 group">
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl ${task.color} flex items-center justify-center text-xl`}>
                {task.icon}
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-slate-800 group-hover:text-primary transition-colors">{task.title}</h4>
                <p className="text-xs text-slate-400 font-medium">{task.subject} • {task.time}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-200" />
            </div>
          </Card>
        ))}
      </div>
    </section>
  </div>
);

const RoadmapScreen = () => (
  <div className="flex-1 flex flex-col gap-6 p-6 overflow-y-auto no-scrollbar">
    <div className="flex flex-col gap-2">
      <h2 className="text-2xl font-bold">Lộ trình của bạn</h2>
      <p className="text-slate-400 text-sm font-medium">Cá nhân hóa cho mục tiêu 8.5+</p>
    </div>

    <div className="flex-1 flex flex-col gap-0">
      {[
        { status: 'completed', title: 'Nền tảng kiến thức', desc: 'Ôn tập toàn bộ lý thuyết cơ bản lớp 11-12' },
        { status: 'active', title: 'Luyện kỹ năng nâng cao', desc: 'Tập trung vào các dạng bài 8-9 điểm' },
        { status: 'upcoming', title: 'Tổng ôn & Giải đề sát', desc: 'Làm quen với cấu trúc đề thi chính thức' },
        { status: 'upcoming', title: 'Về đích', desc: 'Rà soát lỗi sai và ổn định tâm lý' },
      ].map((item, i) => (
        <div key={i} className="flex gap-4 min-h-[120px]">
          <div className="flex flex-col items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
              item.status === 'completed' ? 'bg-primary text-white' : 
              item.status === 'active' ? 'bg-secondary text-white shadow-lg shadow-secondary/30 ring-4 ring-secondary/10' : 
              'bg-slate-100 text-slate-400'
            }`}>
              {item.status === 'completed' ? <CheckCircle2 className="w-5 h-5" /> : <span>{i+1}</span>}
            </div>
            {i !== 3 && <div className={`w-0.5 flex-1 ${item.status === 'completed' ? 'bg-primary' : 'bg-slate-100'} my-1`} />}
          </div>
          <div className={`flex-1 pb-8 ${item.status === 'active' ? 'pt-0' : 'pt-1'}`}>
            <h4 className={`font-bold ${item.status === 'upcoming' ? 'text-slate-400' : 'text-slate-800'}`}>
              {item.title}
              {item.status === 'active' && <span className="ml-2 text-[10px] bg-secondary text-white px-2 py-0.5 rounded-full uppercase tracking-widest font-black">Hiện tại</span>}
            </h4>
            <p className="text-sm text-slate-400 mt-1 leading-relaxed">{item.desc}</p>
            {item.status === 'active' && (
              <div className="mt-4 flex gap-2">
                <Button className="py-2 px-4 text-xs">Vào học ngay</Button>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  </div>
);

const StudyStoreScreen = () => (
  <div className="flex-1 flex flex-col gap-6 p-6 overflow-y-auto no-scrollbar">
    <div className="bg-slate-100 rounded-2xl flex items-center px-4 py-1">
      <Search className="w-5 h-5 text-slate-400" />
      <input type="text" placeholder="Tìm tài liệu, bài giảng..." className="flex-1 bg-transparent border-none py-4 text-sm focus:ring-0" />
    </div>

    <div className="grid grid-cols-2 gap-4">
      {['Video bài giảng', 'Tài liệu PDF', 'Flashcards', 'Audio văn học'].map((type, i) => (
        <Card key={i} className="flex flex-col gap-4 p-4 border-none bg-slate-50 hover:bg-slate-100 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm">
            {[<BookOpen />, <Library />, <Target />, <Award />][i]}
          </div>
          <span className="font-bold text-slate-700 text-sm">{type}</span>
        </Card>
      ))}
    </div>

    <section>
      <h3 className="font-bold text-slate-800 mb-4">Tài liệu phổ biến</h3>
      <div className="flex flex-col gap-3">
        {[1, 2, 3].map((_, i) => (
          <div key={i} className="flex items-center gap-4 p-2">
            <div className="w-16 h-20 bg-primary/5 rounded-lg flex items-center justify-center text-primary font-black uppercase text-[10px] p-2 text-center leading-tight">
              Sổ tay công thức Toán
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-slate-800 text-sm">Chinh phục 9+ Toán THPT</h4>
              <p className="text-xs text-slate-400 mt-0.5">3.2k lượt tải • PDF</p>
            </div>
            <button className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
              <LogOut className="w-4 h-4 rotate-90" />
            </button>
          </div>
        ))}
      </div>
    </section>
  </div>
);

const ExamScreen = () => (
  <div className="flex-1 flex flex-col gap-6 p-6 overflow-y-auto no-scrollbar">
    <Card className="bg-secondary text-white border-none p-6">
      <h3 className="text-xl font-bold mb-1">Kiểm tra năng lực</h3>
      <p className="text-secondary-foreground/70 text-sm font-medium mb-6">Đề thi được tổng hợp theo đúng cấu trúc Bộ Giáo dục</p>
      <Button variant="secondary" className="bg-white text-secondary hover:bg-slate-100">Bắt đầu thi thử</Button>
    </Card>

    <div className="flex flex-col gap-4">
      <h3 className="font-bold text-slate-800">Lịch sử làm đề</h3>
      {[
        { title: 'Đề Toán cụm trường chuyên', score: '8.6', status: 'high' },
        { title: 'Đề Anh 2023 - Lần 2', score: '7.8', status: 'avg' },
        { title: 'Đề Lý chương 1 & 2', score: '9.2', status: 'high' },
      ].map((exam, i) => (
        <Card key={i} className="p-4">
          <div className="flex justify-between items-center">
            <div>
              <h4 className="font-bold text-slate-800 text-sm">{exam.title}</h4>
              <p className="text-xs text-slate-400 mt-1">15/05/2026</p>
            </div>
            <div className="text-right">
              <span className={`text-lg font-black ${exam.status === 'high' ? 'text-primary' : 'text-amber-500'}`}>{exam.score}</span>
              <p className="text-[10px] text-slate-300 font-bold uppercase tracking-widest">Điểm số</p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  </div>
);

const ProfileScreen = () => (
  <div className="flex-1 flex flex-col gap-8 p-6 overflow-y-auto no-scrollbar">
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        <div className="w-24 h-24 rounded-full bg-slate-100 p-1 border-2 border-primary">
          <div className="w-full h-full rounded-full bg-slate-200 flex items-center justify-center overflow-hidden">
            <User className="w-12 h-12 text-slate-400" />
          </div>
        </div>
        <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-primary rounded-full border-4 border-white flex items-center justify-center text-white">
          <CheckCircle2 className="w-4 h-4" />
        </div>
      </div>
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800">Minh Tâm</h2>
        <p className="text-slate-400 font-medium text-sm">minhtam@student.edu.vn</p>
      </div>
    </div>

    <div className="grid grid-cols-2 gap-4">
      <Card className="bg-slate-50 border-none p-4 text-center">
        <p className="text-xs text-slate-400 font-bold uppercase mb-1">Hạng</p>
        <span className="text-xl font-bold text-primary">#142</span>
      </Card>
      <Card className="bg-slate-50 border-none p-4 text-center">
        <p className="text-xs text-slate-400 font-bold uppercase mb-1">Xu học tập</p>
        <span className="text-xl font-bold text-amber-500">2.5k</span>
      </Card>
    </div>

    <div className="flex flex-col gap-3">
      {[
        { icon: Settings, label: 'Cài đặt tài khoản' },
        { icon: MessageCircle, label: 'Hỏi đáp với Mentor', badge: 'Mới' },
        { icon: Award, label: 'Thành tích & Huy hiệu' },
        { icon: LogOut, label: 'Đăng xuất', color: 'text-error' },
      ].map((item, i) => (
        <button key={i} className="flex items-center justify-between p-4 px-2 hover:bg-slate-50 transition-colors rounded-xl group text-left">
          <div className="flex items-center gap-4">
            <item.icon className={`w-5 h-5 ${item.color || 'text-slate-400'}`} />
            <span className={`font-semibold ${item.color || 'text-slate-700'}`}>{item.label}</span>
          </div>
          <div className="flex items-center gap-2">
            {item.badge && <span className="bg-error text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase">{item.badge}</span>}
            <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-primary transition-all" />
          </div>
        </button>
      ))}
    </div>
  </div>
);

// --- Ask Mentor Floating Action Button ---
const AskMentorFAB = () => (
  <motion.button 
    initial={{ scale: 0, opacity: 0 }}
    animate={{ scale: 1, opacity: 1 }}
    whileHover={{ scale: 1.05 }}
    whileTap={{ scale: 0.95 }}
    className="fixed bottom-32 right-6 w-14 h-14 bg-secondary text-white rounded-full shadow-[0_8px_24px_rgba(0,88,190,0.4)] flex items-center justify-center z-30"
  >
    <MessageCircle className="w-6 h-6" />
    <div className="absolute -top-1 -right-1 w-4 h-4 bg-error text-[8px] font-black flex items-center justify-center rounded-full border-2 border-white">2</div>
  </motion.button>
);

// --- Main Application Wrapper ---

export default function App() {
  const [screen, setScreen] = useState<Screen>('SPLASH');
  const [activeTab, setActiveTab] = useState<Tab>('HOME');

  const handleSplashComplete = () => setScreen('ONBOARDING');
  const handleOnboardingFinish = () => setScreen('LOGIN');
  const handleLogin = () => setScreen('MAIN_APP');
  const handleRegister = () => setScreen('REGISTER');
  const gotoGoals = () => setScreen('GOALS');
  const startApp = () => setScreen('MAIN_APP');

  return (
    <div className="app-container shadow-none border-none max-w-none min-h-screen bg-background">
      <AnimatePresence mode="wait">
        {screen === 'SPLASH' && (
          <motion.div key="splash" className="flex-1 flex flex-col h-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <SplashScreen onComplete={handleSplashComplete} />
          </motion.div>
        )}
        
        {screen === 'ONBOARDING' && (
          <motion.div key="onboarding" className="flex-1 flex flex-col h-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <Onboarding onFinish={handleOnboardingFinish} />
          </motion.div>
        )}
        
        {screen === 'LOGIN' && (
          <motion.div key="login" className="flex-1 flex flex-col h-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <LoginScreen onLogin={handleLogin} onRegister={handleRegister} />
          </motion.div>
        )}
        
        {screen === 'REGISTER' && (
          <motion.div key="register" className="flex-1 flex flex-col h-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <RegisterScreen onBack={() => setScreen('LOGIN')} onSuccess={gotoGoals} />
          </motion.div>
        )}
        
        {screen === 'GOALS' && (
          <motion.div key="goals" className="flex-1 flex flex-col h-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <SetGoalsScreen onComplete={startApp} />
          </motion.div>
        )}

        {screen === 'MAIN_APP' && (
          <motion.div key="main" className="flex-1 flex flex-col h-screen overflow-hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Header title={
              activeTab === 'HOME' ? 'THPT Smart Learn' : 
              activeTab === 'ROADMAP' ? 'Lộ trình cá nhân' : 
              activeTab === 'STORE' ? 'Kho học tập' : 
              activeTab === 'EXAM' ? 'Phòng thi thử' : 
              'Hồ sơ cá nhân'
            } />
            
            <div className="flex-1 overflow-hidden flex flex-col">
              {activeTab === 'HOME' && <HomeScreen />}
              {activeTab === 'ROADMAP' && <RoadmapScreen />}
              {activeTab === 'STORE' && <StudyStoreScreen />}
              {activeTab === 'EXAM' && <ExamScreen />}
              {activeTab === 'PROFILE' && <ProfileScreen />}
            </div>

            {/* Show Ask Mentor FAB on study related tabs */}
            {(activeTab === 'HOME' || activeTab === 'ROADMAP' || activeTab === 'EXAM') && <AskMentorFAB />}

            <BottomNav activeTab={activeTab} setTab={setActiveTab} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
