import React, { useState } from 'react';
import { cn } from './lib/utils';
import { TopBar } from './components/TopBar';
import { Sidebar, BottomNav, type NavTab } from './components/Navigation';
import { DashboardView } from './views/DashboardView';
import { ClassDetailView } from './views/ClassDetailView';
import { QuestionBankView } from './views/QuestionBankView';
import { ScheduleView } from './views/ScheduleView';
import { DocumentView } from './views/DocumentView';
import { ProfileView } from './views/ProfileView';
import { NotificationView } from './views/NotificationView';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [selectedClassId, setSelectedClassId] = useState<string | null>(null);

  const handleSelectClass = (id: string) => {
    setSelectedClassId(id);
    setActiveTab('classes');
  };

  const renderContent = () => {
    if (selectedClassId && activeTab === 'classes') {
      return (
        <ClassDetailView 
          classId={selectedClassId} 
          onBack={() => setSelectedClassId(null)} 
        />
      );
    }

    switch (activeTab) {
      case 'overview':
        return <DashboardView onSelectClass={handleSelectClass} />;
      case 'classes':
        return <DashboardView onSelectClass={handleSelectClass} />;
      case 'questions':
        return <QuestionBankView />;
      case 'calendar':
        return <ScheduleView />;
      case 'documents':
        return <DocumentView />;
      case 'notifications':
        return <NotificationView />;
      case 'profile':
        return <ProfileView />;
      default:
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
            <div className="w-24 h-24 rounded-full bg-primary/5 flex items-center justify-center text-primary/20 mb-6">
              <span className="text-4xl font-headline font-black">?</span>
            </div>
            <h3 className="text-2xl font-headline font-black text-primary mb-2">Đang phát triển</h3>
            <p className="text-on-surface-variant max-w-sm">
              Tính năng "{activeTab}" đang được hoàn thiện. Vui lòng quay lại sau!
            </p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background-base flex flex-col">
      <TopBar teacherName="Đinh Thị Tâm" />
      
      <div className="flex flex-1 pt-20 md:pt-0">
        <Sidebar activeTab={activeTab} onTabChange={(tab) => {
          setActiveTab(tab);
          setSelectedClassId(null);
        }} />
        
        <main className={cn(
          "flex-1 p-6 md:p-12 transition-all duration-300 md:ml-72 md:pt-24",
          "pb-32 md:pb-12"
        )}>
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>

      <BottomNav activeTab={activeTab} onTabChange={(tab) => {
        setActiveTab(tab);
        setSelectedClassId(null);
      }} />
    </div>
  );
}
