import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Library, 
  CheckCircle2, 
  Clock, 
  MoreHorizontal,
  Edit3,
  Trash2
} from 'lucide-react';
import { Card, Button } from '../components/ui/Base';
import { cn } from '../lib/utils';

const QUESTIONS = [
  { id: 1, content: 'Cho hàm số y = (2x - 1)/(x + 1). Khẳng định nào sau đây là đúng về đường tiệm cận của đồ thị hàm số?', subject: 'Toán', topic: 'Hàm số', level: 'Trung bình', status: 'approved' },
  { id: 2, content: 'Một con lắc lò xo treo thẳng đứng dao động điều hòa với chu kì T = 0.4s. Biên độ dao động là A = 8cm...', subject: 'Vật lý', topic: 'Dao động cơ', level: 'Khó', status: 'pending' },
  { id: 3, content: 'Choose the correct answer: "By the time we arrived at the station, the train ________."', subject: 'Tiếng Anh', topic: 'Ngữ pháp', level: 'Dễ', status: 'approved' },
];

export const QuestionBankView = () => {
  const [search, setSearch] = useState('');

  return (
    <div className="space-y-10 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-headline font-black text-primary tracking-tight mb-2">Ngân hàng câu hỏi</h2>
          <p className="text-lg text-on-surface-variant font-medium">Quản lý và duyệt hệ thống câu hỏi trắc nghiệm của bạn.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary">
            <Library size={18} /> Tạo đề từ ngân hàng
          </Button>
          <Button>
            <Plus size={18} /> Thêm câu hỏi
          </Button>
        </div>
      </div>

      {/* Summary Chips */}
      <div className="flex flex-wrap gap-4">
        {[
          { label: 'Tổng số', val: '2,500', color: 'bg-primary/5 text-primary' },
          { label: 'Đã duyệt', val: '2,180', color: 'bg-green-50 text-green-700' },
          { label: 'Chờ duyệt', val: '320', color: 'bg-amber-50 text-amber-700' },
        ].map((chip, i) => (
          <div key={i} className={cn("px-6 py-4 rounded-2xl flex flex-col gap-1 min-w-[140px]", chip.color)}>
            <span className="text-[10px] uppercase font-black tracking-widest opacity-70">{chip.label}</span>
            <span className="text-2xl font-display font-black">{chip.val}</span>
          </div>
        ))}
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" />
          <input 
            type="text" 
            placeholder="Tìm kiếm nội dung câu hỏi..."
            className="bg-white border-none rounded-2xl pl-12 pr-6 py-4 shadow-sm w-full focus:ring-2 focus:ring-primary/10"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Button variant="secondary" className="px-6 rounded-2xl h-[56px]">
          <Filter size={18} /> Bộ lọc nâng cao
        </Button>
      </div>

      {/* Question List */}
      <div className="space-y-4">
        {QUESTIONS.map((q) => (
          <Card key={q.id} className="p-6 relative overflow-hidden group">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-1 space-y-4">
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1 rounded-lg bg-[#edeeef] text-[10px] font-black uppercase tracking-widest text-on-surface-variant">
                    {q.subject}
                  </span>
                  <span className="px-3 py-1 rounded-lg bg-[#edeeef] text-[10px] font-black uppercase tracking-widest text-on-surface-variant">
                    {q.topic}
                  </span>
                  <span className={cn(
                    "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest",
                    q.level === 'Dễ' ? "bg-green-100 text-green-700" : 
                    q.level === 'Khó' ? "bg-red-100 text-red-700" : "bg-blue-100 text-blue-700"
                  )}>
                    {q.level}
                  </span>
                  {q.status === 'approved' ? (
                    <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-green-600">
                      <CheckCircle2 size={12} /> Đã duyệt
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-amber-600">
                      <Clock size={12} /> Chờ duyệt
                    </span>
                  )}
                </div>
                
                <p className="text-lg font-medium text-primary leading-relaxed">
                  {q.content}
                </p>
                
                <div className="flex items-center gap-6 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">
                  <span>Sử dụng: 142 lần</span>
                  <span>Cập nhật: 2 ngày trước</span>
                </div>
              </div>

              <div className="flex md:flex-col gap-2 shrink-0 md:w-12 items-center justify-center border-t md:border-t-0 md:border-l border-[#edeeef] pt-4 md:pt-0 md:pl-6">
                <button className="p-2 rounded-xl hover:bg-primary/5 text-primary transition-colors">
                  <Edit3 size={20} />
                </button>
                <button className="p-2 rounded-xl hover:bg-red-50 text-red-500 transition-colors">
                  <Trash2 size={20} />
                </button>
                <button className="p-2 rounded-xl hover:bg-gray-100 text-on-surface-variant transition-colors">
                  <MoreHorizontal size={20} />
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
