import React from 'react';
import { 
  Users, 
  GraduationCap, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp,
  ArrowRight,
  Plus
} from 'lucide-react';
import { Card, Button } from '../components/ui/Base';
import { cn } from '../lib/utils';

// Helper for Mock Data
const CLASSES = [
  { id: '12A1', students: 42, avgScore: 8.5, progress: 85, alert: 4 },
  { id: '12A2', students: 45, avgScore: 7.8, progress: 70, alert: 0 },
  { id: '12A3', students: 39, avgScore: 7.2, progress: 65, alert: 2 },
];

export const DashboardView = ({ onSelectClass }: { onSelectClass: (id: string) => void }) => {
  return (
    <div className="space-y-12">
      {/* Intro Section */}
      <section>
        <h2 className="text-4xl md:text-5xl font-display font-black text-primary tracking-tight mb-2">
          Chào cô Tâm 👋
        </h2>
        <p className="text-lg text-on-surface-variant font-medium">
          Dưới đây là tổng quan tình hình học tập lớp bạn phụ trách.
        </p>
      </section>

      {/* Stats Bento Grid */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <Card className="p-6 relative group overflow-hidden cursor-pointer hover:-translate-y-1">
          <div className="flex justify-between items-start mb-4">
            <span className="text-sm font-bold text-on-surface-variant/70 uppercase tracking-widest">Tổng số lớp</span>
            <div className="w-10 h-10 rounded-full bg-primary/5 flex items-center justify-center text-primary">
              <GraduationCap size={20} />
            </div>
          </div>
          <p className="text-4xl font-display font-black text-primary">4</p>
          <div className="absolute right-0 bottom-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
            <ArrowRight size={16} className="text-primary" />
          </div>
        </Card>

        <Card className="p-6 relative group overflow-hidden cursor-pointer hover:-translate-y-1">
          <div className="flex justify-between items-start mb-4">
            <span className="text-sm font-bold text-on-surface-variant/70 uppercase tracking-widest">Học sinh</span>
            <div className="w-10 h-10 rounded-full bg-secondary/5 flex items-center justify-center text-secondary">
              <Users size={20} />
            </div>
          </div>
          <p className="text-4xl font-display font-black text-primary">168</p>
        </Card>

        <Card className="p-6 relative group overflow-hidden cursor-pointer hover:-translate-y-1">
          <div className="flex justify-between items-start mb-4">
            <span className="text-sm font-bold text-on-surface-variant/70 uppercase tracking-widest">Hoàn thành</span>
            <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center text-green-600">
              <CheckCircle2 size={20} />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <p className="text-4xl font-display font-black text-primary">92%</p>
            <span className="text-xs font-bold text-green-600 flex items-center">+3% <TrendingUp size={12} /></span>
          </div>
        </Card>

        <Card className="p-6 relative group overflow-hidden cursor-pointer hover:-translate-y-1 bg-red-50/50 ring-1 ring-red-100">
          <div className="flex justify-between items-start mb-4">
            <span className="text-sm font-bold text-red-600/70 uppercase tracking-widest">Cần hỗ trợ</span>
            <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-600">
              <AlertCircle size={20} />
            </div>
          </div>
          <p className="text-4xl font-display font-black text-red-600">18</p>
        </Card>
      </section>

      {/* Quick Actions */}
      <section className="flex flex-wrap gap-4">
        <Button className="h-14">
          <Plus size={20} /> Tạo bài kiểm tra
        </Button>
        <Button variant="secondary" className="h-14">
          Gửi thông báo lớp
        </Button>
        <Button variant="ghost" className="h-14">
          Phân tích tiến độ
        </Button>
      </section>

      {/* Classes Overview */}
      <section>
        <div className="flex justify-between items-end mb-8">
          <h3 className="text-2xl font-display font-black text-primary">Danh sách lớp học</h3>
          <button className="text-secondary font-bold hover:underline">Xem tất cả</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CLASSES.map((cls) => (
            <Card 
              key={cls.id} 
              className="p-6 relative overflow-hidden group cursor-pointer hover:shadow-xl"
              onClick={() => onSelectClass(cls.id)}
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-secondary opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h4 className="text-2xl font-display font-black text-primary">{cls.id}</h4>
                  <p className="text-sm text-on-surface-variant font-bold">{cls.students} học sinh</p>
                </div>
                {cls.alert > 0 && (
                  <span className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter flex items-center gap-1 animate-pulse">
                    <AlertCircle size={12} /> {cls.alert} HS cần hỗ trợ
                  </span>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-background-base rounded-xl">
                  <span className="text-xs font-bold text-on-surface-variant">Điểm trung bình</span>
                  <span className="text-xl font-display font-black text-primary">{cls.avgScore}</span>
                </div>

                <div>
                  <div className="flex justify-between text-[10px] font-black text-on-surface-variant uppercase tracking-widest mb-1.5">
                    <span>Tiến độ chương trình</span>
                    <span className="text-secondary">{cls.progress}%</span>
                  </div>
                  <div className="w-full bg-[#edeeef] h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-secondary h-full rounded-full transition-all duration-1000" 
                      style={{ width: `${cls.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
};
