import React, { useState } from 'react';
import { 
  ArrowLeft, 
  MoreVertical, 
  Users, 
  FileText, 
  ClipboardList, 
  BarChart2,
  MessageSquare,
  Search,
  Filter,
  Plus,
  Send,
  Sparkles,
  TrendingUp
} from 'lucide-react';
import { Card, Button } from '../components/ui/Base';
import { cn } from '../lib/utils';

type ClassTab = 'overview' | 'students' | 'exams' | 'docs' | 'reports';

const STUDENTS = [
  { id: 1, name: 'Nguyễn Văn An', avgScore: 8.2, progress: 95, status: 'good' },
  { id: 2, name: 'Trần Minh Khoa', avgScore: 5.6, progress: 45, status: 'at-risk' },
  { id: 3, name: 'Lê Thanh Mai', avgScore: 6.4, progress: 70, status: 'warning' },
  { id: 4, name: 'Phạm Hùng Anh', avgScore: 7.8, progress: 88, status: 'good' },
  { id: 5, name: 'Vũ Hải Yến', avgScore: 5.2, progress: 38, status: 'at-risk' },
];

export const ClassDetailView = ({ classId, onBack }: { classId: string, onBack: () => void }) => {
  const [activeTab, setActiveTab] = useState<ClassTab>('overview');

  const tabs = [
    { id: 'overview', label: 'Tổng quan', icon: ClipboardList },
    { id: 'students', label: 'Học sinh', icon: Users },
    { id: 'exams', label: 'Bài kiểm tra', icon: FileText },
    { id: 'docs', label: 'Tài liệu', icon: ClipboardList },
    { id: 'reports', label: 'Báo cáo', icon: BarChart2 },
  ];

  return (
    <div className="space-y-8 pb-32">
      {/* Detail Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center text-primary group hover:bg-primary hover:text-white transition-all"
          >
            <ArrowLeft size={20} className="group-active:-translate-x-1 transition-transform" />
          </button>
          <div className="space-y-1">
            <h2 className="text-3xl md:text-4xl font-headline font-black text-primary tracking-tight">
              Lớp {classId}
            </h2>
            <div className="flex items-center gap-4 text-sm font-bold text-on-surface-variant">
              <span>Sĩ số: 42 Học sinh</span>
              <span className="w-1.5 h-1.5 rounded-full bg-gray-300"></span>
              <span>GV: Đinh Thị Tâm</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="secondary" className="px-4">
            <MessageSquare size={18} /> Nhắn cho lớp
          </Button>
          <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors text-on-surface-variant">
            <MoreVertical size={20} />
          </button>
        </div>
      </div>

      {/* Hero Stats (Layered Appearance) */}
      <Card className="p-8 relative overflow-hidden bg-gradient-to-br from-primary/5 to-secondary/5 border-none shadow-none">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-primary">Tiến độ khóa học</h3>
            <div className="flex items-end gap-3">
              <span className="text-6xl font-display font-black text-primary leading-none">82%</span>
              <div className="pb-1">
                <p className="text-sm font-bold text-green-600 flex items-center gap-1">
                  +12% <TrendingUp size={14} />
                </p>
                <p className="text-[10px] uppercase font-bold text-on-surface-variant tracking-widest">so với tuần trước</p>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <div className="bg-white/60 backdrop-blur rounded-2xl p-4 flex justify-between items-center">
              <span className="text-sm font-bold text-on-surface-variant">Điểm trung bình lớp</span>
              <span className="text-2xl font-display font-black text-primary">7.4</span>
            </div>
            <div className="bg-white/60 backdrop-blur rounded-2xl p-4 flex justify-between items-center">
              <span className="text-sm font-bold text-on-surface-variant">Bài tập hoàn thành</span>
              <span className="text-2xl font-display font-black text-secondary">86%</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Tab Switcher */}
      <div className="flex gap-2 overflow-x-auto hide-scrollbar border-b border-[#edeeef] pb-px">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as ClassTab)}
              className={cn(
                "flex items-center gap-2 px-6 py-4 font-bold transition-all relative overflow-hidden whitespace-nowrap",
                isActive 
                  ? "text-primary" 
                  : "text-[#191C1D]/50 hover:text-primary/60"
              )}
            >
              <Icon size={18} />
              <span>{tab.label}</span>
              {isActive && (
                <div className="absolute bottom-0 left-0 w-full h-1 bg-primary rounded-t-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="pt-4">
        {activeTab === 'students' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="relative w-full sm:w-auto">
                <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" />
                <input 
                  type="text" 
                  placeholder="Tìm học sinh..."
                  className="bg-white border-none rounded-full pl-12 pr-6 py-3 shadow-sm focus:ring-2 focus:ring-primary/20 w-full sm:w-80"
                />
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <Button variant="secondary" size="sm">
                  <Filter size={16} /> Lọc
                </Button>
                <Button size="sm">
                  <Plus size={16} /> Thêm HS
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              {STUDENTS.map((student) => (
                <Card key={student.id} className="p-4 flex items-center justify-between group cursor-pointer hover:translate-x-2">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-full flex items-center justify-center font-bold",
                      student.status === 'good' ? "bg-green-100 text-green-700" :
                      student.status === 'warning' ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
                    )}>
                      {student.name.split(' ').map(n => n[0]).join('').slice(-2)}
                    </div>
                    <div>
                      <h4 className="font-bold text-primary">{student.name}</h4>
                      <div className="flex items-center gap-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mt-1">
                        <span>Tiến độ: {student.progress}%</span>
                        <div className="w-1 h-1 rounded-full bg-gray-300" />
                        <span>Trạng thái: {
                          student.status === 'good' ? 'Tiến bộ tốt' : 
                          student.status === 'warning' ? 'Chậm tiến độ' : 'HS Yếu'
                        }</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-on-surface-variant uppercase tracking-widest">Điểm TB</p>
                    <p className={cn(
                      "text-2xl font-display font-black",
                      student.avgScore >= 8 ? "text-green-600" : 
                      student.avgScore >= 6.5 ? "text-primary" : "text-red-500"
                    )}>{student.avgScore}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="p-8 space-y-6">
              <h3 className="text-xl font-headline font-black text-primary">Phân tích theo chủ đề</h3>
              <div className="space-y-6">
                {[
                  { label: 'Hàm số & Đồ thị', val: 8.8, color: 'bg-primary' },
                  { label: 'Tích phân & Ứng dụng', val: 7.2, color: 'bg-blue-400' },
                  { label: 'Số phức', val: 6.5, color: 'bg-amber-500' },
                  { label: 'Khối đa diện', val: 8.1, color: 'bg-primary' },
                ].map((topic, i) => (
                  <div key={i}>
                    <div className="flex justify-between items-end mb-2">
                      <span className="font-bold text-primary">{topic.label}</span>
                      <span className="text-xl font-display font-black">{topic.val}</span>
                    </div>
                    <div className="w-full bg-[#edeeef] h-2 rounded-full overflow-hidden">
                      <div className={cn("h-full rounded-full", topic.color)} style={{ width: `${topic.val * 10}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-8 bg-primary text-white space-y-6 shadow-2xl relative overflow-hidden">
              <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/10 rounded-full blur-3xl" />
              <div className="relative z-10 flex flex-col items-center text-center py-6">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-4">
                  <Sparkles size={32} />
                </div>
                <h3 className="text-2xl font-headline font-black mb-2">Can thiệp sớm</h3>
                <p className="text-sm opacity-80 mb-8 font-medium">
                  Hệ thống phát hiện 6 học sinh đang gặp khó khăn trong chủ đề "Số phức". Hãy tạo lộ trình hỗ trợ ngay!
                </p>
                <Button variant="white" className="w-full text-primary hover:bg-white/90">
                  <Send size={18} /> Tạo kế hoạch hỗ trợ
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};
