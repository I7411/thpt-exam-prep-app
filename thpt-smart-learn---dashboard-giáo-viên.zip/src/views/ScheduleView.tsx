import React from 'react';
import { 
  Plus, 
  ChevronLeft, 
  ChevronRight, 
  MapPin, 
  Users, 
  FileText 
} from 'lucide-react';
import { Card, Button } from '../components/ui/Base';
import { cn } from '../lib/utils';

const SCHEDULE = [
  { time: '07:30 - 09:00', class: '12A1', subject: 'Toán Giải Tích - Chương 3', room: 'A203', kids: 42, tag: 'Kiểm tra 15p' },
  { time: '09:30 - 11:00', class: '12A2', subject: 'Hình Học Không Gian', room: 'B105', kids: 38 },
  { time: '14:00 - 15:30', class: '12A3', subject: 'Toán Ôn Tập - Luyện Đề', room: 'C302', kids: 45, tag: 'Phát đề số 4' },
];

export const ScheduleView = () => {
  return (
    <div className="space-y-10 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-headline font-black text-primary tracking-tight mb-2">Lịch giảng dạy</h2>
          <p className="text-lg text-on-surface-variant font-medium">Quản lý các lớp học và thời gian của bạn.</p>
        </div>
        <Button>
          <Plus size={18} /> Tạo lịch mới
        </Button>
      </div>

      {/* Calendar Mini */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-8 px-2">
          <div className="flex items-center gap-4">
            <button className="p-2 rounded-full hover:bg-gray-100"><ChevronLeft size={20} /></button>
            <h3 className="text-xl font-headline font-black text-primary">Tháng 3, 2024</h3>
            <button className="p-2 rounded-full hover:bg-gray-100"><ChevronRight size={20} /></button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((d) => (
            <div key={d} className="text-center text-[10px] font-black text-on-surface-variant uppercase tracking-widest pb-2">
              {d}
            </div>
          ))}
          {[...Array(31)].map((_, i) => {
            const day = i + 1;
            const isToday = day === 15;
            const hasEvent = [17, 19, 24].includes(day);
            return (
              <button 
                key={i}
                className={cn(
                  "aspect-square rounded-2xl flex flex-col items-center justify-center relative transition-all",
                  isToday ? "bg-primary text-white shadow-lg" : "hover:bg-primary/5 text-primary/70 font-bold"
                )}
              >
                <span className="text-sm">{day}</span>
                {hasEvent && !isToday && (
                  <div className="absolute bottom-1.5 w-1 h-1 rounded-full bg-secondary" />
                )}
              </button>
            );
          })}
        </div>
      </Card>

      {/* Timeline */}
      <section className="space-y-8">
        <div className="flex items-center gap-3">
          <h3 className="text-2xl font-headline font-black text-primary">Thứ Hai 15/03</h3>
          <span className="bg-secondary/10 text-secondary px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
            3 buổi học
          </span>
        </div>

        <div className="relative pl-8 md:pl-32 space-y-6">
          {/* Vertical Line */}
          <div className="absolute left-[31px] md:left-[111px] top-4 bottom-4 w-1 bg-[#edeeef] rounded-full" />
          
          {SCHEDULE.map((item, i) => (
            <div key={i} className="relative group animate-in fade-in slide-in-from-left-4 duration-500" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="absolute left-[-5px] md:left-[-5px] top-6 w-3 h-3 rounded-full bg-white border-2 border-primary z-10 group-hover:bg-primary transition-colors" />
              
              <div className="hidden md:block absolute left-[-110px] top-5 w-24 text-right">
                <p className="text-sm font-black text-primary">{item.time.split(' - ')[0]}</p>
                <p className="text-[10px] font-bold text-on-surface-variant">{item.time.split(' - ')[1]}</p>
              </div>

              <Card className="p-6 relative overflow-hidden group hover:shadow-xl transition-all cursor-pointer">
                <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-primary" />
                
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-2xl font-display font-black text-primary">Lớp {item.class}</h4>
                        {item.tag && (
                          <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-tighter">
                            {item.tag}
                          </span>
                        )}
                      </div>
                      <p className="text-sm font-bold text-on-surface-variant leading-tight">
                        {item.subject}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-[10px] font-black text-on-surface-variant uppercase tracking-widest">
                      <div className="flex items-center gap-1.5">
                        <MapPin size={12} className="text-primary/40" /> {item.room}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Users size={12} className="text-primary/40" /> {item.kids} học sinh
                      </div>
                    </div>
                  </div>
                  
                  <Button variant="ghost" size="sm" className="w-fit">
                    Chi tiết <ChevronRight size={16} />
                  </Button>
                </div>
              </Card>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
