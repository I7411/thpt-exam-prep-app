import React from 'react';
import { 
  Bell, 
  CheckCircle2, 
  AlertCircle, 
  Info, 
  Plus,
  Send,
  MoreVertical
} from 'lucide-react';
import { Card, Button } from '../components/ui/Base';
import { cn } from '../lib/utils';

const NOTIFICATIONS = [
  { id: 1, title: '12A1 nộp bài stats', content: 'Lớp 12A1 đã hoàn thành bài kiểm tra Toán Đại Số. Tỉ lệ nộp bài đạt 100%.', time: 'Vừa xong', type: 'success' },
  { id: 2, title: 'Cảnh báo điểm thấp Đề 03', content: 'Có 15 học sinh dưới điểm trung bình trong bài kiểm tra Đề 03 môn Vật Lý.', time: '2 giờ trước', type: 'alert' },
  { id: 3, title: 'Tài liệu mới đã xuất bản', content: 'Tài liệu "Đề cương ôn tập Học kỳ 2" đã được gửi cho toàn bộ học sinh khối 12.', time: 'Hôm qua', type: 'info' },
];

export const NotificationView = () => {
  return (
    <div className="space-y-10 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-headline font-black text-primary tracking-tight mb-2">Thông báo</h2>
          <p className="text-lg text-on-surface-variant font-medium">Cập nhật các hoạt động và nhắc nhở mới nhất.</p>
        </div>
        <Button>
          <Plus size={18} /> Tạo thông báo mới
        </Button>
      </div>

      <div className="flex gap-2 overflow-x-auto hide-scrollbar">
        {['Tất cả', 'Lớp học', 'Bài kiểm tra', 'Tài liệu'].map((label, i) => (
          <button 
            key={i}
            className={cn(
              "px-6 py-2.5 rounded-full font-bold text-sm transition-all whitespace-nowrap",
              i === 0 ? "bg-secondary text-white shadow-lg" : "bg-[#edeeef] text-on-surface-variant hover:bg-[#e1e3e4]"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {NOTIFICATIONS.map((n) => (
          <Card key={n.id} className="p-6 relative overflow-hidden group hover:bg-gray-50 cursor-pointer">
            <div className="flex gap-6">
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center shrink-0 shadow-sm",
                n.type === 'success' ? "bg-green-50 text-green-600" :
                n.type === 'alert' ? "bg-red-50 text-red-600" : "bg-primary/5 text-primary"
              )}>
                {n.type === 'success' ? <CheckCircle2 size={24} /> :
                 n.type === 'alert' ? <AlertCircle size={24} /> : <Info size={24} />}
              </div>
              
              <div className="flex-1 space-y-2">
                <div className="flex justify-between items-start">
                  <h3 className="text-xl font-bold text-primary">{n.title}</h3>
                  <span className="text-[10px] font-black text-on-surface-variant uppercase tracking-widest">{n.time}</span>
                </div>
                <p className="text-on-surface-variant font-medium leading-relaxed max-w-2xl">
                  {n.content}
                </p>
                <div className="pt-2 flex gap-4">
                  <button className="text-[10px] font-black text-secondary uppercase tracking-widest hover:underline flex items-center gap-1">
                    Xem chi tiết <Send size={10} />
                  </button>
                </div>
              </div>

              <div className="hidden md:flex">
                <button className="p-2 rounded-full hover:bg-gray-100 text-on-surface-variant">
                  <MoreVertical size={20} />
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
