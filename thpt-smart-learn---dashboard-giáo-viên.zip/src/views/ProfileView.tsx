import React from 'react';
import { 
  User, 
  Mail, 
  Book, 
  Settings, 
  ShieldCheck, 
  LogOut, 
  Edit3,
  ChevronRight,
  Sparkles,
  Bell
} from 'lucide-react';
import { Card, Button } from '../components/ui/Base';
import { cn } from '../lib/utils';

export const ProfileView = () => {
  return (
    <div className="space-y-10 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <h2 className="text-4xl font-headline font-black text-primary tracking-tight">Hồ sơ cá nhân</h2>
        <Button variant="secondary">
          <Edit3 size={18} /> Chỉnh sửa thông tin
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-1 p-8 flex flex-col items-center text-center">
          <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-xl mb-6 relative group cursor-pointer">
            <img 
              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=300&h=300" 
              alt="Teacher"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
               <Edit3 className="text-white" size={24} />
            </div>
          </div>
          <h3 className="text-2xl font-headline font-black text-primary mb-1">Đinh Thị Tâm</h3>
          <p className="text-sm font-bold text-on-surface-variant uppercase tracking-widest mb-6">Giáo viên Toán học</p>
          
          <div className="w-full space-y-3">
             <div className="flex items-center gap-3 p-3 bg-[#edeeef] rounded-xl text-sm font-medium">
               <Mail size={16} className="text-primary/40" /> dinhthitam@smartlearn.vn
             </div>
             <div className="flex items-center gap-3 p-3 bg-[#edeeef] rounded-xl text-sm font-medium">
               <Book size={16} className="text-primary/40" /> Chuyên môn: Giải tích, Hình học
             </div>
          </div>

          <div className="mt-8 pt-8 border-t border-[#edeeef] w-full">
            <Button variant="error" className="w-full">
              <LogOut size={18} /> Đăng xuất
            </Button>
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-8">
          <Card className="p-8 space-y-6">
            <h4 className="text-xl font-headline font-black text-primary flex items-center gap-2">
              <Settings size={20} className="text-secondary" /> Cấu hình hệ thống
            </h4>
            
            <div className="space-y-2">
              {[
                { label: 'Thông báo đẩy', desc: 'Nhận tin nhắn từ học sinh và nhắc lịch', icon: Bell },
                { label: 'Quyền truy cập', desc: 'Quản lý vai trò và quyền hạn (Admin locked)', icon: ShieldCheck, locked: true },
                { label: 'Trợ lý AI SmartLearn', desc: 'Bật gợi ý lộ trình học tự động cho học sinh yếu', icon: Sparkles },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-all cursor-pointer group">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary">
                      <item.icon size={20} />
                    </div>
                    <div>
                      <p className="font-bold text-primary">{item.label}</p>
                      <p className="text-xs text-on-surface-variant font-medium">{item.desc}</p>
                    </div>
                  </div>
                  {item.locked ? (
                     <div className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Khóa</div>
                  ) : (
                    <ChevronRight size={18} className="text-on-surface-variant group-hover:translate-x-1 transition-transform" />
                  )}
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-8 bg-gradient-to-br from-secondary to-blue-700 text-white shadow-2xl">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="flex-1 space-y-2">
                <h4 className="text-2xl font-headline font-black">Nâng cấp Gói Premium</h4>
                <p className="opacity-80 text-sm font-medium">Bản quyền của bạn còn 45 ngày. Gia hạn để tiếp tục sử dụng kho 50,000+ câu hỏi và trợ lý ảo AI.</p>
              </div>
              <Button variant="white" className="text-secondary hover:bg-white/90 shrink-0">Gia hạn ngay</Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
