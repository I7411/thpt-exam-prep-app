import React from 'react';
import { 
  Search, 
  Plus, 
  FileText, 
  Eye, 
  Download, 
  MoreVertical,
  BookOpen,
  Filter
} from 'lucide-react';
import { Card, Button } from '../components/ui/Base';
import { cn } from '../lib/utils';

const DOCS = [
  { id: 1, title: 'Chuyên đề Hàm số', subject: 'Toán', views: 124, status: 'published', type: 'pdf' },
  { id: 2, title: 'Bộ câu hỏi đọc hiểu', subject: 'Ngữ văn', views: 0, status: 'draft', type: 'docx' },
  { id: 3, title: 'Tổng hợp ngữ pháp', subject: 'Tiếng Anh', views: 89, status: 'published', type: 'pdf' },
];

export const DocumentView = () => {
  return (
    <div className="space-y-10 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-headline font-black text-primary tracking-tight mb-2">Tài liệu ôn tập</h2>
          <p className="text-lg text-on-surface-variant font-medium">Quản lý và chia sẻ tài liệu học tập của bạn.</p>
        </div>
        <Button>
          <Plus size={18} /> Thêm tài liệu
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" />
          <input 
            type="text" 
            placeholder="Tìm kiếm tài liệu..."
            className="bg-white border-none rounded-2xl pl-12 pr-6 py-4 shadow-sm w-full focus:ring-2 focus:ring-primary/10"
          />
        </div>
        <Button variant="secondary" className="px-6 rounded-2xl h-[56px]">
          <Filter size={18} /> Lọc theo môn
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {DOCS.map((doc) => (
          <Card key={doc.id} className="p-6 flex flex-col h-full relative overflow-hidden group hover:shadow-xl">
             <div className="flex justify-between items-start mb-6">
               <div className={cn(
                 "p-3 rounded-xl shadow-sm",
                 doc.type === 'pdf' ? "bg-red-50 text-red-500" : "bg-blue-50 text-blue-500"
               )}>
                 <FileText size={28} />
               </div>
               <span className={cn(
                 "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest",
                 doc.status === 'published' ? "bg-green-50 text-green-600" : "bg-[#edeeef] text-on-surface-variant"
               )}>
                 {doc.status === 'published' ? 'Đã xuất bản' : 'Bản nháp'}
               </span>
             </div>

             <div className="flex-1 space-y-1 mb-8">
               <h3 className="text-xl font-bold text-primary mb-1 line-clamp-2">{doc.title}</h3>
               <p className="text-sm font-bold text-on-surface-variant uppercase tracking-widest">{doc.subject}</p>
             </div>

             <div className="pt-6 border-t border-[#edeeef] flex justify-between items-center text-[10px] font-black text-on-surface-variant uppercase tracking-widest">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1"><Eye size={12} /> {doc.views} lượt xem</span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors"><Download size={16} className="text-secondary" /></button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors"><MoreVertical size={16} /></button>
                </div>
             </div>
          </Card>
        ))}
      </div>

      {/* Decorative Empty State placeholder */}
      {DOCS.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
          <div className="w-24 h-24 rounded-full bg-primary/5 flex items-center justify-center text-primary/20">
            <BookOpen size={48} />
          </div>
          <div>
            <h3 className="text-2xl font-headline font-black text-primary">Chưa có tài liệu</h3>
            <p className="text-on-surface-variant">Hãy bắt đầu bằng cách tải lên giáo án hoặc chuyên đề mới.</p>
          </div>
          <Button>Tải lên ngay</Button>
        </div>
      )}
    </div>
  );
};
