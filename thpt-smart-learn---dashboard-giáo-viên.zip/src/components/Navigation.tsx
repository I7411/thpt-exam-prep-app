import React from 'react';
import { 
  BarChart3, 
  Users, 
  HelpCircle, 
  CalendarDays, 
  User,
  LayoutDashboard,
  Bell,
  BookOpen
} from 'lucide-react';
import { cn } from '../lib/utils';

export type NavTab = 'overview' | 'classes' | 'questions' | 'calendar' | 'profile' | 'notifications' | 'documents';

interface BottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const BottomNav = ({ activeTab, onTabChange }: BottomNavProps) => {
  const tabs = [
    { id: 'overview', label: 'Tổng quan', icon: BarChart3 },
    { id: 'classes', label: 'Lớp học', icon: Users },
    { id: 'questions', label: 'Câu hỏi', icon: HelpCircle },
    { id: 'calendar', label: 'Lịch dạy', icon: CalendarDays },
    { id: 'profile', label: 'Cá nhân', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 pb-6 pt-3 bg-white/80 backdrop-blur-xl shadow-[0_-4px_20px_rgba(0,35,111,0.05)] rounded-t-xl md:hidden">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id as NavTab)}
            className={cn(
              "flex flex-col items-center justify-center transition-all p-2 rounded-xl",
              isActive 
                ? "bg-secondary/10 text-secondary" 
                : "text-[#191C1D]/60 hover:bg-gray-100"
            )}
          >
            <Icon size={isActive ? 24 : 22} strokeWidth={isActive ? 2.5 : 2} />
            <span className={cn("text-[10px] mt-1 font-semibold", isActive ? "text-secondary" : "")}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};

export const Sidebar = ({ activeTab, onTabChange }: BottomNavProps) => {
  const items = [
    { id: 'overview', label: 'Tổng quan', icon: LayoutDashboard },
    { id: 'classes', label: 'Lớp học', icon: Users },
    { id: 'documents', label: 'Tài liệu', icon: BookOpen },
    { id: 'questions', label: 'Câu hỏi', icon: HelpCircle },
    { id: 'calendar', label: 'Lịch giảng dạy', icon: CalendarDays },
    { id: 'notifications', label: 'Thông báo', icon: Bell },
    { id: 'profile', label: 'Cá nhân', icon: User },
  ];

  return (
    <aside className="hidden md:flex flex-col w-72 h-screen fixed left-0 top-0 bg-white border-r border-[#edeeef] p-6 pt-24 z-40">
      <div className="flex flex-col gap-2">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id as NavTab)}
              className={cn(
                "flex items-center gap-4 px-4 py-3 rounded-xl font-bold transition-all",
                isActive 
                  ? "bg-primary text-white shadow-lg" 
                  : "text-[#191C1D]/60 hover:bg-primary/5 hover:text-primary"
              )}
            >
              <Icon size={20} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
      
      <div className="mt-auto p-4 bg-primary/5 rounded-2xl flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          <User size={20} />
        </div>
        <div className="overflow-hidden">
          <p className="text-sm font-bold text-primary truncate">Cô Đinh Thị Tâm</p>
          <p className="text-xs text-on-surface-variant">Giáo viên Toán</p>
        </div>
      </div>
    </aside>
  );
};
