import React from 'react';
import { Bell, Menu, User } from 'lucide-react';

interface TopBarProps {
  teacherName: string;
}

export const TopBar = ({ teacherName }: TopBarProps) => {
  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-[#edeeef] px-6 py-4 flex justify-between items-center md:pl-[300px]">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border-2 border-primary/10">
          <img 
            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150&h=150" 
            alt="Teacher"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="hidden sm:block">
          <h1 className="font-headline font-black text-xl text-primary leading-tight">
            THPT Smart Learn
          </h1>
          <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">
            Hệ thống quản lý giáo viên
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="hidden sm:flex flex-col items-end mr-2">
          <p className="text-xs font-bold text-primary">Xin chào, {teacherName}</p>
          <p className="text-[10px] text-on-surface-variant">Môn: Toán học • 4 Lớp</p>
        </div>
        <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors text-primary relative">
          <Bell size={20} />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
      </div>
    </header>
  );
};
