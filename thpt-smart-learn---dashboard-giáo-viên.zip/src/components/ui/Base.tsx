import React, { ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'white' | 'low';
}

export const Card: React.FC<CardProps> = ({ children, className, variant = 'white', ...props }) => {
  return (
    <div
      className={cn(
        "rounded-xl transition-all duration-300",
        variant === 'white' ? "bg-white shadow-[0_12px_32px_rgba(0,35,111,0.04)]" : "bg-[#edeeef]",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'error' | 'white';
  size?: 'sm' | 'md' | 'lg';
}

export const Button: React.FC<ButtonProps> = ({
  children,
  className,
  variant = 'primary',
  size = 'md',
  ...props
}) => {
  const variants = {
    primary: "bg-gradient-to-br from-primary to-primary-light text-white shadow-[0_8px_16px_rgba(0,35,111,0.15)] hover:opacity-90",
    secondary: "bg-[#e1e3e4] text-[#191C1D] hover:bg-[#c5c5d3]",
    ghost: "bg-transparent text-primary hover:bg-primary/5",
    error: "bg-red-50 text-red-600 hover:bg-red-100",
    white: "bg-white text-[#191C1D] hover:bg-gray-50",
  };

  const sizes = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-6 py-3",
    lg: "px-8 py-4 text-lg",
  };

  return (
    <button
      className={cn(
        "rounded-full font-semibold transition-all active:scale-95 flex items-center justify-center gap-2",
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};
