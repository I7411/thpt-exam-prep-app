import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  UserModel? _user;
  bool _isLoading = false;

  UserModel? get user => _user;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _user != null;

  final ApiService _apiService = ApiService();

  Future<bool> login(String email, String password) async {
    _setLoading(true);
    try {
      // Giả lập gọi API
      await Future.delayed(const Duration(seconds: 2));
      
      // Demo logic
      if (email == "student@test.com") {
        _user = UserModel(
          id: "1",
          fullName: "Nguyễn Văn Học Sinh",
          email: email,
          role: UserRole.student,
          className: "12A1",
        );
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void logout() {
    _user = null;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
