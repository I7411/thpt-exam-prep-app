import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // Đối với Android Emulator: http://10.0.2.2:PORT
  // Đối với Android thật: http://IP_LAN_MAY_TINH:PORT
  static const String baseUrl = "http://192.168.1.10:5000/api";

  Future<dynamic> get(String endpoint) async {
    try {
      final response = await http.get(Uri.parse("$baseUrl/$endpoint"));
      return _handleResponse(response);
    } catch (e) {
      throw Exception("Lỗi kết nối: $e");
    }
  }

  Future<dynamic> post(String endpoint, Map<String, dynamic> data) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/$endpoint"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(data),
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception("Lỗi kết nối: $e");
    }
  }

  dynamic _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return jsonDecode(response.body);
    } else {
      throw Exception("Lỗi API: ${response.statusCode}");
    }
  }
}
