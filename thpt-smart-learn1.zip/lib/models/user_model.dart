enum UserRole { student, teacher, admin }

class UserModel {
  final String id;
  final String fullName;
  final String email;
  final UserRole role;
  final String? className;
  final String? avatarUrl;

  UserModel({
    required this.id,
    required this.fullName,
    required this.email,
    required this.role,
    this.className,
    this.avatarUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      fullName: json['fullName'],
      email: json['email'],
      role: _parseRole(json['role']),
      className: json['className'],
      avatarUrl: json['avatarUrl'],
    );
  }

  static UserRole _parseRole(String role) {
    switch (role.toLowerCase()) {
      case 'teacher': return UserRole.teacher;
      case 'admin': return UserRole.admin;
      default: return UserRole.student;
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'fullName': fullName,
      'email': email,
      'role': role.toString().split('.').last,
      'className': className,
      'avatarUrl': avatarUrl,
    };
  }
}
